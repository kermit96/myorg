package myorgwork.sample.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Samplecontroller {
	@RequestMapping(value = "/sample/readSample.do")
	public String MareadSample() throws Exception {

		   // logService.InsertLog("MIS_MO_MAP_01", LogType.VIEW, "주요 모니터링", "주요 모니터링  조회");
			return "/sample/readSample";
	}

	@RequestMapping(value = "/sample/uploadsample.do")
	public String uploadsample() throws Exception {

		   // logService.InsertLog("MIS_MO_MAP_01", LogType.VIEW, "주요 모니터링", "주요 모니터링  조회");
			return "/sample/uploadsample";
	}


}
