package myorgwork.mypage.service.impl;

import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import myorgwork.mypage.vo.Page0001S001VO;
import myorgwork.mypage.vo.Page0001S002VO;

@Mapper("Page0001Mapper")
public interface Page0001Mapper {

	Page0001S001VO page0001_s001(String kUserSeq);
	List page0001_s002(String userId);
}
