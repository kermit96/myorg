package myorgwork.mypage.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import myorgwork.mypage.service.Page0001Service;
import myorgwork.mypage.vo.Page0001S001VO;
import myorgwork.mypage.vo.Page0001S002VO;

// 관리자 - 메뉴관리
@Service("Page0001Service")
public class Page0001ServiceImpl implements Page0001Service {
//	private static final Logger log = LoggerFactory.getLogger(AD001ServiceImpl.class);

	@Resource(name="Page0001Mapper")
	private Page0001Mapper page0001Mapper;

	@Override
	public Page0001S001VO page0001_s001( String kUserSeq ) throws Exception {

		return page0001Mapper.page0001_s001(kUserSeq);
	}
	@Override
	public List page0001_s002( String userId ) throws Exception {

		return page0001Mapper.page0001_s002(userId);
	}

}
