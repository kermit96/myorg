package myorgwork.mypage.service;

import java.util.List;

import myorgwork.mypage.vo.Page0001S001VO;
import myorgwork.mypage.vo.Page0001S002VO;

//관리자 - 메뉴관리
public interface Page0001Service {

	// 사원정보 조회
	public Page0001S001VO page0001_s001( String kUserSeq ) throws Exception;


	// 프로젝트 정보 조회
	public List page0001_s002( String userId ) throws Exception;

}
