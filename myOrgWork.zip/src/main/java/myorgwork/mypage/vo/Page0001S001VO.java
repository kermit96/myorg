package myorgwork.mypage.vo;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 * @Class Name : LoginVO.java
 * @Description : Login VO class
 * @Modification Information
 * @
 * @  수정일         수정자                   수정내용
 * @ -------    --------    ---------------------------
 * @ 2009.03.03    박지욱          최초 생성
 *
 *  @author 공통서비스 개발팀 박지욱
 *  @since 2009.03.03
 *  @version 1.0
 *  @see
 *  
 */
public class Page0001S001VO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8274004534207618049L;
	
	
	
	
	private String kUserSeq;  			// 사용자 고유번호         
	private String dirPath;  			// 사용자 사진정보
	private String userId;  			// 사번
	private String userNm;	 			// 사용자 이름
	private String userEngNm; 			// 사용자 영문이름
	private String deptCd;	 			// 부서코드
	private String deptNm;	 			// 부서이름
	private String jobIf;	 			// 현 직급 정보
	private String phoneIf;  			// 연락처 정보
	private String emailIf;  			// 이메일 정보
	private String assignTaskIf;  		// 담당업무 정보
	private String enterComDt;  		// 입사일자
	private String enterYearNum;  		// 연차
	private String drtLineIf;			// 직계
	private String dutyGroupNm;			// 직무그룹
	public String getkUserSeq() {
		return kUserSeq;
	}
	public void setkUserSeq(String kUserSeq) {
		this.kUserSeq = kUserSeq;
	}
	public String getPhotoFileSeq() {
		return dirPath;
	}
	public void setPhotoFileSeq(String photoFileSeq) {
		this.dirPath = photoFileSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getUserEngNm() {
		return userEngNm;
	}
	public void setUserEngNm(String userEngNm) {
		this.userEngNm = userEngNm;
	}
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getDeptNm() {
		return deptNm;
	}
	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	public String getJobIf() {
		return jobIf;
	}
	public void setJobIf(String jobIf) {
		this.jobIf = jobIf;
	}
	public String getPhoneIf() {
		return phoneIf;
	}
	public void setPhoneIf(String phoneIf) {
		this.phoneIf = phoneIf;
	}
	public String getEmailIf() {
		return emailIf;
	}
	public void setEmailIf(String emailIf) {
		this.emailIf = emailIf;
	}
	public String getAssignTaskIf() {
		return assignTaskIf;
	}
	public void setAssignTaskIf(String assignTaskIf) {
		this.assignTaskIf = assignTaskIf;
	}
	public String getEnterComDt() {
		return enterComDt;
	}
	public void setEnterComDt(String enterComDt) {
		this.enterComDt = enterComDt;
	}
	public String getEnterYearNum() {
		return enterYearNum;
	}
	public void setEnterYearNum(String enterYearNum) {
		this.enterYearNum = enterYearNum;
	}
	public String getDrtLineIf() {
		return drtLineIf;
	}
	public void setDrtLineIf(String drtLineIf) {
		this.drtLineIf = drtLineIf;
	}
	public String getDutyGroupNm() {
		return dutyGroupNm;
	}
	public void setDutyGroupNm(String dutyGroupNm) {
		this.dutyGroupNm = dutyGroupNm;
	}
	
	
	
	
	
}
