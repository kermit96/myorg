package myorgwork.mypage.vo;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 * @Class Name : LoginVO.java
 * @Description : Login VO class
 * @Modification Information
 * @
 * @  수정일         수정자                   수정내용
 * @ -------    --------    ---------------------------
 * @ 2009.03.03    박지욱          최초 생성
 *
 *  @author 공통서비스 개발팀 박지욱
 *  @since 2009.03.03
 *  @version 1.0
 *  @see
 *
 */
public class Page0001S002VO implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = -8274004534207618049L;


	private String	pjtId;			// 프로젝트 ID
	private String  pjtNm;          // 프로젝트 이름
	private String  pjtSDt;         // 사업기간 시작일자
	private String  pjtEDt;         // 사업기간 종료일자
	private String  charger1Nm;     // 원청 담당자
	private String  charger2Nm;     // 하청 담당자
	private String  charger3Nm;     // 본사 담당자
	private String  mmNum;          // 투입 M/M
	private String  estmtAmt;       // 프로젝트 비용

	public String getPjtId() {
		return pjtId;
	}
	public void setPjtId(String pjtId) {
		this.pjtId = pjtId;
	}
	public String getPjtNm() {
		return pjtNm;
	}
	public void setPjtNm(String pjtNm) {
		this.pjtNm = pjtNm;
	}
	public String getPjtSDt() {
		return pjtSDt;
	}
	public void setPjtSDt(String pjtSDt) {
		this.pjtSDt = pjtSDt;
	}
	public String getPjtEDt() {
		return pjtEDt;
	}
	public void setPjtEDt(String pjtEDt) {
		this.pjtEDt = pjtEDt;
	}
	public String getCharger1Nm() {
		return charger1Nm;
	}
	public void setCharger1Nm(String charger1Nm) {
		this.charger1Nm = charger1Nm;
	}
	public String getCharger2Nm() {
		return charger2Nm;
	}
	public void setCharger2Nm(String charger2Nm) {
		this.charger2Nm = charger2Nm;
	}
	public String getCharger3Nm() {
		return charger3Nm;
	}
	public void setCharger3Nm(String charger3Nm) {
		this.charger3Nm = charger3Nm;
	}
	public String getMmNum() {
		return mmNum;
	}
	public void setMmNum(String mmNum) {
		this.mmNum = mmNum;
	}
	public String getEstmtAmt() {
		return estmtAmt;
	}
	public void setEstmtAmt(String estmtAmt) {
		this.estmtAmt = estmtAmt;
	}



}
