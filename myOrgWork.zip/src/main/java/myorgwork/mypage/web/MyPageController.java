package myorgwork.mypage.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import myorgwork.mypage.service.Page0001Service;
import myorgwork.mypage.vo.Page0001S001VO;
import myorgwork.mypage.vo.Page0001S002VO;

@Controller
public class MyPageController {

	/** log */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(MyPageController.class);

	@Resource(name = "Page0001Service")
	Page0001Service page0001Service;

	@RequestMapping(value = "/mypage.do")
	public String mypage(HttpServletRequest request, HttpServletResponse response) throws Exception {

		return "/pop_mypage";
	}


	@RequestMapping(value = "/page0001_s001.do", produces="text/plain;charset=UTF-8")
	public @ResponseBody String page0001_s001(HttpServletRequest request) throws Exception
	{
		try {
			Page0001S001VO vo = page0001Service.page0001_s001(request.getParameter("kUserSeq"));
			Gson gson = new Gson();
			return gson.toJson(vo);
		}
		catch (Exception e) {
			LOGGER.debug(e.getMessage());
		}
		return "";
	}

	@RequestMapping(value = "/page0001_s002.do", produces="text/plain;charset=UTF-8")
	public @ResponseBody String page0001_s002(HttpServletRequest request) throws Exception
	{
		try {
			List vo = page0001Service.page0001_s002(request.getParameter("userId"));
			Gson gson = new Gson();
			return gson.toJson(vo);
		}
		catch (Exception e) {
			LOGGER.debug(e.getMessage());
		}
		return "";
	}
}
