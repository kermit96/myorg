package myorgwork.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

// import egovframework.com.cmm.service.Globals;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/**
 * <pre>
 * 6. 설명 :
 * </pre>
 */

public class CommonUtil {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(CommonUtil.class);

	/**
	 *
	 * <pre>
	 * 4. 설명 : Map<String, String> paramMap = CommonUtil.getParameter(request.getParameterMap());
	 * </pre>
	 *
	 * @param paramMap
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static EgovMap getParameterObj(Map<String, String[]> paramMap) {
		ArrayList<String> keyList = getKeyList(paramMap);

		EgovMap map = new EgovMap();

		for (int i = 0; i < keyList.size(); i++) {

			String key = keyList.get(i);
			String value = (String) paramMap.get(keyList.get(i))[0].trim();

			// logger.debug("[Map Key Value] paramKey[" + i + "] : " + key +
			// " value : " + value);

			if (value != null && !value.equals("") && !value.equals("null")) {
				map.put(key, value);

				if (isNumber(value)) {
					try {
						map.put(key, (Integer) Integer.parseInt(value));
					} catch (Exception e) {
						map.put(key, value);
					}
				} else {
					map.put(key, value);
				}
			} else { // null인 경우 key가 생성되지 않는 경우 보완
				map.put(key, "");
			}
		}


		return map;
	}

	private static ArrayList<String> getKeyList(Map<String, String[]> paramMap) {
		// logger.debug("=================getKeyList start==================");
		Set<String> keySet = paramMap.keySet();
		Iterator<String> it = keySet.iterator();

		ArrayList<String> keyList = new ArrayList<String>();

		while (it.hasNext()) {
			String key = it.next();
			keyList.add(key);
			// logger.debug("key = " + key);
		}

		// logger.debug("=================getKeyList end==================");

		return keyList;
	}

	// 숫자형 데이터와 문자형 데이터 구분
	private static boolean isNumber(String str) {
		boolean check = true;
		for (int i = 0; i < str.length(); i++) {
			if (i == 0) {
				Character cr = new Character(str.charAt(i));
				String vstr = cr.toString();
				if (vstr.equals("0")) {
					check = false;
					break;
				}
			} else {
				if (!Character.isDigit(str.charAt(i))) {
					check = false;
					break;
				} // end if
			}
		} // end for
		return check;
	} // isNumber

	/**
	 *
	 * <pre>
	 * 4. 설명 :
	 * </pre>
	 *
	 * @param paramMap
	 * @return
	 */
	public static Map<String, String[]> getParameterArray(
			Map<String, String[]> paramMap) {

		Set<String> keySet = paramMap.keySet();
		Iterator<String> it = keySet.iterator();

		Map<String, String[]> map = new HashMap<String, String[]>();

		while (it.hasNext()) {
			String key = it.next();
			String[] value = (String[]) paramMap.get(key);

			map.put(key, value);
		}
		return map;
	}

	public static String getCurrentMethod() {
		Exception e = new Exception();
		StackTraceElement[] ste = e.getStackTrace();
		String message = ste[1].getMethodName();
		// for(int i=0; i < 20 && i < ste.length; i++)
		// message += ste[i].getClassName() + "(" + ste[i].getFileName() +":" +
		// ste[i].getLineNumber() + ")\n";
		return message;
	}

	public static String getCurrentClass() {
		Exception e = new Exception();
		StackTraceElement[] ste = e.getStackTrace();
		String message = ste[1].getClassName();
		// for(int i=0; i < 20 && i < ste.length; i++)
		// message += ste[i].getClassName() + "(" + ste[i].getFileName() +":" +
		// ste[i].getLineNumber() + ")\n";
		return message;
	}

	public static StackTraceElement getCurrentSTE() {
		Exception e = new Exception();
		StackTraceElement[] ste = e.getStackTrace();
		return ste[1];
	}

	/**
	 *
	 * <pre>
	 * 4. 설명 :
	 * </pre>
	 *
	 * @param paramMap
	 * @return
	 */

	public static Map<String, String> getAttachFileMap(
			HttpServletRequest request) {

		if (!(request instanceof MultipartHttpServletRequest)) {
			return null;
		}

		MultipartHttpServletRequest multipart = (MultipartHttpServletRequest) request;
		Map<String, MultipartFile> mapFile = multipart.getFileMap();

		Iterator<String> iterator = mapFile.keySet().iterator();

		// MultipartFile multipartFile = null;
		// while (iterator.hasNext()) {
		// multipartFile = multipartHttpServletRequest.getFile(iterator.next());
		// if (multipartFile.isEmpty() == false) {
		// log.debug("------------- file start -------------");
		// log.debug("name : " + multipartFile.getName());
		// log.debug("filename : " + multipartFile.getOriginalFilename());
		// log.debug("size : " + multipartFile.getSize());
		// log.debug("-------------- file end --------------\n");
		// }
		// }
		return null;
	}

	public static String getDate(String format) throws ParseException,
			java.text.ParseException {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		return dateFormat.format(date);
	}

	public static String getCal(String format, int year, int month, int days) throws ParseException,
		java.text.ParseException {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, year);
		cal.add(Calendar.MONTH, month);
		cal.add(Calendar.DAY_OF_MONTH, days);
		return dateFormat.format(cal.getTime());
	}


	public static void DeleteDirectory(File file) {
		if (!file.exists())
			return;

		File[] files = file.listFiles();

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory())
				DeleteDirectory(files[i]);
			else
				files[i].delete();
		}

		file.delete();
	}

	// 디렉토리 안의 파일을 삭제 한다.
	public static void ClearDirectory(String filename) {
		File file = new File(filename);
		ClearDirectory(file);
	}

	public static void ClearDirectory(File file) {
		if (!file.exists())
			return;

		File[] files = file.listFiles();

		if(files.length==0) {
			file.delete();
			return;
		}
		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory()) {
				ClearDirectory(files[i]);
				files[i].delete();
			} else
				files[i].delete();
		}

	}

	// 디렉토리 를 만든다.

	public static void CreateDirectory(String dir) {
		File file = new File(dir);
		if (file.exists())
			return;

		boolean ret = file.mkdirs();

	}

	// 디렉토리 파일중 가장 최신 것을 가져온다.
	public static String GetFirstFile(String dir) {
		File directory = new File(dir);

		if (directory.exists() == false)
			return "";
		File[] files = directory.listFiles();

		Arrays.sort(files, new Comparator<File>() {
			public int compare(File f1, File f2) {
				return -Long.compare(f1.lastModified(), f2.lastModified());
			}
		});

		if (files.length == 0)
			return "";

		return files[0].getPath();
	}

	public static void ClearDirectory(File file, long limit) {
		if (!file.exists())
			return;

		File[] files = file.listFiles();

		if(null==files)
			return;

		for (int i = 0; i < files.length; i++) {
			if (files[i].isDirectory())
				ClearDirectory(files[i], limit);
			else if (files[i].lastModified() < limit)
				files[i].delete();
		}

		if (files.length == 0 && file.lastModified() < limit)
			file.delete();
	}

	public static void copyFile(File src, File tgt) throws Exception {
		InputStream is = null;
		OutputStream os = null;
		try {

			System.out.println("src="+src);
			System.out.println("tgt="+tgt);

			is = new FileInputStream(src);
			os = new FileOutputStream(tgt);
			int numRead;
			byte b[] = new byte[1024];
			while ((numRead = is.read(b, 0, b.length)) != -1) {
				os.write(b, 0, numRead);
			}
			os.flush();
			os.close();
		} catch (Exception e) {
			LOGGER.error("Copy File error:"+e.getMessage());
			throw e;
		} finally {
			if (is != null)
				try { is.close(); } catch (Exception ig) { } finally { is = null; }
			if (os != null)
				try { os.close(); } catch (Exception ig) { } finally { os = null; }
		}
	}


	static public String checkNull(Object o) {
		if (o instanceof Integer || o instanceof Long || o instanceof Float
				|| o instanceof Double || o instanceof BigDecimal)
			return "" + o.toString();
		if (o == null || "null".equals((String) o))
			return "";
		return (String) o;
	}












	public static String toCamelCase(String target) {
		StringBuffer buffer = new StringBuffer();
		for (String token : target.toLowerCase().split("_")){
			buffer.append(StringUtils.capitalize(token));
		}
		return StringUtils.uncapitalize(buffer.toString());
	}

	//
	static public String HtmlDecode(String str) {

		return org.springframework.web.util.HtmlUtils.htmlUnescape(str);
	}


	static public String getFileExtension(String filename) {
	  return FilenameUtils.getExtension(filename);

	}


	static public long getFileSize(String filename) {

	        // Define the file Object
	        File myFile = new File(filename);

	        // Get the size of the file
	        long size = myFile.length();


	        return size;

	}

	static public void checkEncoding(String s)
			throws UnsupportedEncodingException {
		byte[] BOM = new byte[4];
		BOM = s.getBytes();

		// 3. 파일 인코딩 확인하기
		if ((BOM[0] & 0xFF) == 0xEF && (BOM[1] & 0xFF) == 0xBB
				&& (BOM[2] & 0xFF) == 0xBF)
			System.out.println("UTF-8");
		else if ((BOM[0] & 0xFF) == 0xFE && (BOM[1] & 0xFF) == 0xFF)
			System.out.println("UTF-16BE");
		else if ((BOM[0] & 0xFF) == 0xFF && (BOM[1] & 0xFF) == 0xFE)
			System.out.println("UTF-16LE");
		else if ((BOM[0] & 0xFF) == 0x00 && (BOM[1] & 0xFF) == 0x00
				&& (BOM[0] & 0xFF) == 0xFE && (BOM[1] & 0xFF) == 0xFF)
			System.out.println("UTF-32BE");
		else if ((BOM[0] & 0xFF) == 0xFF && (BOM[1] & 0xFF) == 0xFE
				&& (BOM[0] & 0xFF) == 0x00 && (BOM[1] & 0xFF) == 0x00)
			System.out.println("UTF-32LE");
		else
			System.out.println("EUC-KR");

		String word = s;
		System.out.println("utf-8(1) : "
				+ new String(word.getBytes("utf-8"), "euc-kr"));
		System.out.println("utf-8(2) : "
				+ new String(word.getBytes("utf-8"), "ksc5601"));
		System.out.println("utf-8(3) : "
				+ new String(word.getBytes("utf-8"), "x-windows-949"));
		System.out.println("utf-8(4) : "
				+ new String(word.getBytes("utf-8"), "iso-8859-1"));

		System.out.println("iso-8859-1(1) : "
				+ new String(word.getBytes("iso-8859-1"), "euc-kr"));
		System.out.println("iso-8859-1(2) : "
				+ new String(word.getBytes("iso-8859-1"), "ksc5601"));
		System.out.println("iso-8859-1(3) : "
				+ new String(word.getBytes("iso-8859-1"), "x-windows-949"));
		System.out.println("iso-8859-1(4) : "
				+ new String(word.getBytes("iso-8859-1"), "utf-8"));

		System.out.println("euc-kr(1) : "
				+ new String(word.getBytes("euc-kr"), "ksc5601"));
		System.out.println("euc-kr(2) : "
				+ new String(word.getBytes("euc-kr"), "utf-8"));
		System.out.println("euc-kr(3) : "
				+ new String(word.getBytes("euc-kr"), "x-windows-949"));
		System.out.println("euc-kr(4) : "
				+ new String(word.getBytes("euc-kr"), "iso-8859-1"));

		System.out.println("ksc5601(1) : "
				+ new String(word.getBytes("ksc5601"), "euc-kr"));
		System.out.println("ksc5601(2) : "
				+ new String(word.getBytes("ksc5601"), "utf-8"));
		System.out.println("ksc5601(3) : "
				+ new String(word.getBytes("ksc5601"), "x-windows-949"));
		System.out.println("ksc5601(4) : "
				+ new String(word.getBytes("ksc5601"), "iso-8859-1"));

		System.out.println("x-windows-949(1) : "
				+ new String(word.getBytes("x-windows-949"), "euc-kr"));
		System.out.println("x-windows-949(2) : "
				+ new String(word.getBytes("x-windows-949"), "utf-8"));
		System.out.println("x-windows-949(3) : "
				+ new String(word.getBytes("x-windows-949"), "ksc5601"));
		System.out.println("x-windows-949(4) : "
				+ new String(word.getBytes("x-windows-949"), "iso-8859-1"));
	}


	public static void checkDir(String serverLoc) throws FileNotFoundException,
    	IOException {

		String filesDir = Globals.FILES_DIR; // PropertyResources.getInstance().getProperty("Files.Dir");
		int idx1 = 0, idx2 = 0;
		String location = null;
		File dir = null;

		serverLoc = serverLoc.replaceAll("[\\\\|/]", "/");

		while (true) {
			idx2 = serverLoc.indexOf("/", idx1);
			if (idx2 < 0)
				location = serverLoc;
			else
				location = serverLoc.substring(0, idx2);

			dir = new File(location);
			if (!dir.exists())
				dir.mkdir();

			if (idx2 < 0)
				break;

			idx1 = idx2 + 1;
		}
	}


}
