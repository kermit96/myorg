package myorgwork.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GlobalProperty {



	public String  GetValue(String key) {


		InputStream is =
			    this.getClass().getClassLoader().getResourceAsStream(
			                                         "/egovframework/properties/globals.properties");

		String fileDir = "";

		  Properties properties = new Properties();
		    // Read properties file.
		    try {
		      properties.load(is);
		      fileDir = properties.getProperty(key,"");
		    } catch (IOException e) {


		    } finally {
		    	try {
		    	is.close();
		    	} catch (Exception ex) {

		    	}

		    }

        return fileDir;
	}

}
