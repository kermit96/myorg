package myorgwork.util;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import myorgwork.login.vo.LoginVO;

public class LoginUtil {

	// login 사용자 정보 가져 오기
		static  public Object getAuthenticatedUser() {

			if (RequestContextHolder.getRequestAttributes() == null) {
				return null;
			}

			return RequestContextHolder.getRequestAttributes().getAttribute("loginVO", RequestAttributes.SCOPE_SESSION);

	    }

		static public Boolean isAuthenticated() {
			// 인증된 유저인지 확인한다.
			if (RequestContextHolder.getRequestAttributes() == null) {
				return false;
			} else {

				if (RequestContextHolder.getRequestAttributes().getAttribute("loginVO", RequestAttributes.SCOPE_SESSION) == null) {
					return false;
				} else {
					return true;
				}
			}

		}


		   // login 사용자의 id 를 알려준다,
		   static public String GetLoginId() {
			   LoginVO login =  	 (LoginVO) getAuthenticatedUser();
			   if(null == login)
				   return null;
			   return login.getLoginId();
		   }


		   static public Long GetLoginSeq() {
			   LoginVO login =  	 (LoginVO) getAuthenticatedUser();
			   if(null == login)
				   return -99999L;
			   return login.getLoginSeq();
		   }





}
