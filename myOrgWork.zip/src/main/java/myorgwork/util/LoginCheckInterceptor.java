package myorgwork.util;



import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import myorgwork.login.service.LoginService;
import myorgwork.login.vo.LoginVO;


// login 처리를 위한  interceptor 
public class LoginCheckInterceptor extends HandlerInterceptorAdapter {

	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginCheckInterceptor.class);
	

	@Resource(name="LoginService")
	private LoginService loginService;
	
	
	@Override
	 public boolean preHandle(HttpServletRequest request,
			   HttpServletResponse response, Object handler) throws Exception {
		
		  // session검사

		    LoginVO logininfo = (LoginVO)  request.getSession().getAttribute("loginVO");
	
			String context = request.getContextPath(); 
			
			String url = request.getRequestURI();
			String queryString = request.getQueryString();
	
			url = url.substring(context.length());
			

			
			if (queryString == null)
				queryString = "";
				
			if (queryString.isEmpty()== false) 
				url = url+"?"+queryString;
			
			if(logininfo == null || logininfo.getUserId() == null || logininfo.getUserId().equals("")){				
				
				response.sendRedirect(request.getContextPath()+"/login.do?url="+URLEncoder.encode(url, "UTF-8"));	
				return false;
			}
			
		    
		  //  다국어 처리  
		 		 
			//checkLang(request,logininfo);
			
		  return true;
	 }
	


	
}
