package myorgwork.util;

public class Globals {

	public static String  FILES_DIR  = new GlobalProperty().GetValue("Files.Dir");

}
