package myorgwork.file.vo;

import java.io.File;

public class fileVo {



	private Long fileSeq;  // file seq
	private Long fKeySeq;  // file_key
	private String fileNm ;
	private String  fileOrgNm;
	private String dirPathIf;
	private Long  fileSizeIf;
	private String extensionIf;
	private Long userSeq;


	public Long getFileSeq() {
		return fileSeq;
	}
	public void setFileSeq(Long fileSeq) {
		this.fileSeq = fileSeq;
	}
	public Long getfKeySeq() {
		return fKeySeq;
	}
	public void setfKeySeq(Long fKeySeq) {
		this.fKeySeq = fKeySeq;
	}
	public String getFileNm() {
			return fileNm;
		// return file.getName();
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getFileOrgNm() {
		return fileOrgNm;
	}
	public void setFileOrgNm(String fileOrgNm) {
		this.fileOrgNm = fileOrgNm;
	}
	public String getDirPathIf() {
		return dirPathIf;
	}
	public void setDirPathIf(String dirPathIf) {


		this.dirPathIf = dirPathIf;
	}
	public Long getFileSizeIf() {
		return fileSizeIf;
	}
	public void setFileSizeIf(Long fileSizeIf) {
		this.fileSizeIf = fileSizeIf;
	}
	public String getExtensionIf() {
		return extensionIf;
	}
	public void setExtensionIf(String extensionIf) {
		this.extensionIf = extensionIf;
	}
	public Long getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(Long userSeq) {
		this.userSeq = userSeq;
	}

}
