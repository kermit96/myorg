package myorgwork.file.service;

import java.util.List;

import myorgwork.file.vo.fileVo;

public interface FileService {
	public Long   SP_FILE_SEQ();
	public  List  SP_FILE_LIST(String fileSeq);
	public  void  SP_FILE_SAVE(fileVo vo);
	public  void  SP_FILE_DELETE(fileVo vo);



}
