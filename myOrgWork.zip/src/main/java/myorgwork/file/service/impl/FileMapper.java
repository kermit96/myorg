package myorgwork.file.service.impl;

import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import myorgwork.file.vo.fileVo;
import myorgwork.login.vo.LoginVO;

@Mapper("FileMapper")
public interface FileMapper {
	Long   SP_FILE_SEQ();
	 List  SP_FILE_LIST(String fileSeq);
	 void  SP_FILE_SAVE(fileVo vo);
	  void  SP_FILE_DELETE(fileVo vo);
}


