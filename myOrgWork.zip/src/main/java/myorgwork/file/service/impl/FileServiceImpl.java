package myorgwork.file.service.impl;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import myorgwork.login.vo.LoginVO;
import myorgwork.file.service.FileService;
import myorgwork.file.vo.fileVo;
import myorgwork.login.service.LoginService;


/**
 * 일반 로그인, 인증서 로그인을 처리하는 비즈니스 구현 클래스
 * @author 공통서비스 개발팀 박지욱
 * @since 2009.03.06
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자          수정내용
 *  -------    --------    ---------------------------
 *  2009.03.06  박지욱          최초 생성
 *  2011.08.26  서준식          EsntlId를 이용한 로그인 추가
 *  2014.12.08	이기하			암호화방식 변경(EgovFileScrty.encryptPassword)
 *  </pre>
 */
@Service("FileService")
public class FileServiceImpl extends EgovAbstractServiceImpl implements FileService {


	@Resource(name="FileMapper")
	private FileMapper fileMappper;

	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(FileServiceImpl.class);

	@Override
	public Long SP_FILE_SEQ() {
		// TODO Auto-generated method stub
		return fileMappper.SP_FILE_SEQ();
	}

	@Override
	public List SP_FILE_LIST(String fileSeq) {
		// TODO Auto-generated method stub

		return fileMappper.SP_FILE_LIST(fileSeq);
	}

	@Override
	public void SP_FILE_SAVE(fileVo vo) {
		// TODO Auto-generated method stub
		fileMappper.SP_FILE_SAVE(vo);
	}

	@Override
	public void SP_FILE_DELETE(fileVo vo) {
		// TODO Auto-generated method stub
		fileMappper.SP_FILE_DELETE(vo);
	}

    //

}
