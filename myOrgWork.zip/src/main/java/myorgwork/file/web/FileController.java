package myorgwork.file.web;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.enterprise.inject.Model;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;

import myorgwork.file.service.FileService;
import myorgwork.file.vo.fileVo;
import myorgwork.main.web.MainController;
import myorgwork.util.CommonUtil;
import myorgwork.util.Globals;
import myorgwork.util.LoginUtil;

@Controller
public class FileController {
	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(MainController.class);
	@Resource(name = "FileService")
	private FileService fileService;


	@RequestMapping(value = "/file/downloadFile.do")
	public @ResponseBody void downloadFile(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// /logService.InsertLog("FILE", 1, "첨부화일 다운로드");
		String fileName = (String) request.getParameter("filename");
		// /fileName= new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
		String pathName = Globals.FILES_DIR
				+ (String) request.getParameter("pathname");



		response.setHeader(
				"Content-Disposition",
				"attachment;filename="
						+ URLEncoder.encode(
								(String) request.getParameter("filename"),
								"UTF-8").replaceAll("\\+", " "));
		// /response.setContentType("text/html; charset=UTF-8");
		response.setHeader("Content-Transfer-Encoding", "binary");
		FileInputStream fis = null;
		BufferedInputStream bis = null;

		ServletOutputStream sos = response.getOutputStream();
		fis = new FileInputStream(pathName);

		byte[] b = new byte[1024];
		bis = new BufferedInputStream(fis);
		for (int len = 0; (len = bis.read(b)) > 0;) {
			sos.write(b, 0, len);
		}
		sos.flush();
	}





	@RequestMapping(value = "/file/getFileSeq.do")
	public @ResponseBody String  getFileSeq() throws Exception {

		   // logService.InsertLog("MIS_MO_MAP_01", LogType.VIEW, "주요 모니터링", "주요 모니터링  조회");

		// 	return "/main";
		try {
		return fileService.SP_FILE_SEQ()+"";
		} catch (Exception ex) {
		  ex.printStackTrace();
		  throw ex;
		}

	}




	@RequestMapping(value = "/file/deleteFileIgnore.do")
	public @ResponseBody String deleteFileIgnore() throws Exception {

		Map map = new HashMap();
		map.put("status", "success");
		return new Gson().toJson(map);
	}



	@RequestMapping(value = "/file/FileList.do")
	public @ResponseBody String FileList(String fileSeq) throws Exception {


		try {
		Gson  gson = new Gson();

	//	System.out.println("FileSeq="+fileSeq);

		List list =  fileService.SP_FILE_LIST(fileSeq);
		return gson.toJson(list);
		} catch (Exception ex) {

			ex.printStackTrace();
			throw ex;
		}
		// 	return "/main";
	}



	@RequestMapping(value = "/file/uploadFile.do", produces = "text/plain;charset=UTF-8")
	public @ResponseBody String uploadFile(HttpServletRequest request)
			throws FileNotFoundException, IOException {
		// /logService.InsertLog("FILE", 0, "첨부화일 임시 업로드");

		try {

			System.out.println("uploadFile="+"");
		String tempLoc = (String) request.getParameter("tempLoc");
		List<String> fileKey = (List) new Gson().fromJson(
				(String) request.getParameter("fileKey"), List.class);

		String tempFilePath = Globals.FILES_DIR + "/" + tempLoc;
		for (Object key : fileKey) {
			if (key instanceof Double)
				key = ("" + key).replaceFirst("\\..*", "");
			tempFilePath += "/" + key;
		}
		CommonUtil.checkDir(tempFilePath);



		MultipartHttpServletRequest multipart = (MultipartHttpServletRequest) request;
		Map<String, MultipartFile> mapFile = multipart.getFileMap();
		MultipartFile multipartFile = mapFile.get("files");

		InputStream is = null;
		OutputStream os = null;
		String rtnJson = null;

		Map map = new HashMap();
		Gson gson = new Gson();

		try {
			is = multipartFile.getInputStream();
			os = new FileOutputStream(new File(tempFilePath + "/"
					+ multipartFile.getOriginalFilename()));
			int numRead;
			byte b[] = new byte[(int) multipartFile.getSize()];
			while ((numRead = is.read(b, 0, b.length)) != -1) {
				os.write(b, 0, numRead);
			}
			os.flush();
			os.close();

			map.put("status", "success");
		} catch (Exception e) {
			map.put("status", "error");
			map.put("errMsg", e.toString() + ':' + e.getMessage());
		} finally {
			try {
				rtnJson = gson.toJson(map);
			} catch (Exception e1) {
			}
			if (is != null)
				try {
					is.close();
				} catch (Exception ig) {
				} finally {
					is = null;
				}
			if (os != null)
				try {
					os.close();
				} catch (Exception ig) {
				} finally {
					os = null;
				}
		}
		return rtnJson;

		} catch (Exception ex) {

			ex.printStackTrace();
			throw ex;
		}
	}

	@RequestMapping(value = "/file/saveFileUploaded.do", produces = "text/plain;charset=UTF-8")
	public @ResponseBody String saveFileUploaded(HttpServletRequest request)
			throws Exception {
		Gson gson = new Gson();

		Map params = (Map) new Gson().fromJson(
				(String) request.getParameter("params"), Map.class);
		Map fileLoc = (Map) params.get("fileLoc");
		List<String> fileKey = (List<String>) fileLoc.get("fileKey");
		String saveLoc = (String) params.get("saveLoc");
		String tempLoc = (String) params.get("tempLoc");

		Map map = new HashMap();
		String rtnJson = null;
		String proc = null;

		try {
			String serverFilePath = Globals.FILES_DIR + "/" + saveLoc;

			String saveLoc2 = saveLoc;
			for (Object key : fileKey) {
				if (key instanceof Double)
					key = ("" + key).replaceFirst("\\..*", "");
				serverFilePath += "/" + key;
				saveLoc2  += "/" +key;
			}





			String fileSeq = fileLoc.get("fileSeq").toString();


			// delete server files
			List<Map> delRecords = (List<Map>) params.get("deletedFiles");
			if (null != delRecords && !delRecords.isEmpty()) {
				for (Map m : delRecords)
					new File(serverFilePath + "/" + (String) m.get("name")).delete();
				proc = (String) params.get("delProc");
				// fileLoc.put("files", delRecords);
				deleteFile(delRecords);
			}

			// move temp to server files
			String tempFilePath = Globals.FILES_DIR + "/" + tempLoc;
			for (Object key : fileKey) {
				if (key instanceof Double)
					key = ("" + key).replaceFirst("\\..*", "");
				tempFilePath += "/" + key;
			}
			List<Map> listRecords = (List<Map>) params.get("listedFiles");


			System.out.println(listRecords);
			for (Map m : listRecords) {
				if (null != m.get("no")) // file added recently
					continue;

				// m.put("fileKey", fileKey);
				m.put("size", m.get("size") == null ? "" : m.get("size")
						.toString());

				File src = new File(tempFilePath + "/" + (String) m.get("name"));
				File tgt = new File(serverFilePath + "/"
						+ (String) m.get("name"));

				CommonUtil.CreateDirectory(serverFilePath);
				CommonUtil.copyFile(src, tgt);


				SaveFiles(saveLoc2,m, tgt.length() ,fileSeq );
				// src.renameTo(tgt);
			}



			CommonUtil.ClearDirectory(tempFilePath);

			map.put("status", "success");
		} catch (Exception e) {
			e.printStackTrace();
			map.put("status", "error");
			map.put("errMsg", e.toString() + ':' + e.getMessage());
		} finally {
			try {
				rtnJson = gson.toJson(map);
			} catch (Exception e1) {
			}
		}

		return rtnJson;
	}



	 void deleteFile (List<Map> delRecords) {


		 for(Map map :delRecords) {

			 if (map.get("no") == null)
				 continue;
		     fileVo vo = new fileVo ();
		     vo.setFileSeq((long)map.get("fileSeq"));
		     vo.setfKeySeq((Long)map.get("no"));

		     fileService.SP_FILE_DELETE(vo);
		 }



	 }


	void SaveFiles (String saveLoc ,Map map,Long filesize,String fileSeq) {



		     fileVo vo = new fileVo ();
		     vo.setFileSeq(Long.parseLong(fileSeq));
//		     vo.setfKeySeq((long)map.get("fKeySeq"));


			 vo.setDirPathIf(saveLoc);

			 String filename = (String)map.get("name");
			 vo.setExtensionIf( CommonUtil.getFileExtension(filename) );
			 vo.setFileNm(filename);
			 vo.setFileOrgNm(filename);
			 vo.setDirPathIf(saveLoc);
             vo.setFileSizeIf(filesize);
             vo.setUserSeq(LoginUtil.GetLoginSeq());
             fileService.SP_FILE_SAVE(vo);

	 }




	// downloadFile.do

}
