package myorgwork.login.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import myorgwork.login.service.LoginService;
import myorgwork.login.vo.LoginVO;

@Controller
public class LoginController {

	/** log */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(LoginController.class);
	/** EgovLoginService */
	@Resource(name = "LoginService")
	private LoginService loginService;

	/**
	 * 로그인 화면으로 들어간다
	 *
	 * @param vo
	 *            - 로그인후 이동할 URL이 담긴 useVO
	 * @return 로그인 페이지
	 * @exception Exception
	 */

	@RequestMapping(value = "/login.do")
	public String loginUsrView(@ModelAttribute("loginVO") LoginVO loginVO,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap model) throws Exception {

		String url = request.getParameter("url");

		if (url == null)
			url = "";

		url = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4(url);

		model.addAttribute("url", url);
		return "/login";
	}

	/**
	 * 일반 로그인을 처리한다
	 *
	 * @param vo
	 *            LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
	@RequestMapping(value = "/actionLogin.do")
	@ResponseBody
	public String actionLogin( LoginVO loginVO,
			HttpServletRequest request, HttpServletResponse response
			) throws Exception {




		try {
		LoginVO rsltLoginVo = loginService.actionLogin(loginVO);

		if ( rsltLoginVo == null ) return "N";

		if ( loginVO.getPasswordIf().equals(rsltLoginVo.getPasswordIf()) )
		{
			request.getSession().setAttribute("loginVO", rsltLoginVo);
			return "Y";
		}
		else
			return "N";
		} catch (Exception ex) {
			ex.printStackTrace();
			return "N";
		}
	}


	/**
	 * 로그아웃한다.
	 *
	 * @return String
	 * @exception Exception
	 */
	@RequestMapping(value = "/actionLogout.do")
	public String actionLogout(HttpServletRequest request, ModelMap model)
			throws Exception {

		request.getSession().setAttribute("loginVO", null);
		request.getSession().invalidate();
		// return "GEIS/login/LoginUsr";
		return "redirect:/login.do";
	}

}
