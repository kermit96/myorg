package myorgwork.login.vo;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


/**
 * @Class Name : LoginVO.java
 * @Description : Login VO class
 * @Modification Information
 * @
 * @  수정일         수정자                   수정내용
 * @ -------    --------    ---------------------------
 * @ 2009.03.03    박지욱          최초 생성
 *
 *  @author 공통서비스 개발팀 박지욱
 *  @since 2009.03.03
 *  @version 1.0
 *  @see
 *
 */
public class LoginVO implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = -8274004534207618049L;



	private long   loginSeq;            // user seq
	private String loginId;             // login Id
	private String userId;  			// 사원 ID
	private String passwordIf;  		// 패스워드
	private String userNm;  			// 사원이름
	private String deptCd;  			// 현 소속부서
	private String phoneIf;  			// 현 직급정보
	private String emailIf;  			// 연락처 정보
	private String assignTaskIf;  		// 이메일 정보
	private String photoFileSeq;  		// 담당업무 정보
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPasswordIf() {
		return passwordIf;
	}
	public void setPasswordIf(String passwordIf) {
		this.passwordIf = passwordIf;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getPhoneIf() {
		return phoneIf;
	}
	public void setPhoneIf(String phoneIf) {
		this.phoneIf = phoneIf;
	}
	public String getEmailIf() {
		return emailIf;
	}
	public void setEmailIf(String emailIf) {
		this.emailIf = emailIf;
	}
	public String getAssignTaskIf() {
		return assignTaskIf;
	}
	public void setAssignTaskIf(String assignTaskIf) {
		this.assignTaskIf = assignTaskIf;
	}
	public String getPhotoFileSeq() {
		return photoFileSeq;
	}
	public void setPhotoFileSeq(String photoFileSeq) {
		this.photoFileSeq = photoFileSeq;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public long getLoginSeq() {
		return loginSeq;
	}
	public void setLoginSeq(long loginSeq) {
		this.loginSeq = loginSeq;
	}



}
