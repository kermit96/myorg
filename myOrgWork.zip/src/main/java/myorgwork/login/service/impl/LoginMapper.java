package myorgwork.login.service.impl;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import myorgwork.login.vo.LoginVO;

@Mapper("LoginMapper")
public interface LoginMapper {
	LoginVO actionLogin(LoginVO vo);
}
