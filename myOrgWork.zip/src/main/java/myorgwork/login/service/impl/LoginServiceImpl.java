package myorgwork.login.service.impl;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import myorgwork.login.vo.LoginVO;
import myorgwork.login.service.LoginService;


/**
 * 일반 로그인, 인증서 로그인을 처리하는 비즈니스 구현 클래스
 * @author 공통서비스 개발팀 박지욱
 * @since 2009.03.06
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자          수정내용
 *  -------    --------    ---------------------------
 *  2009.03.06  박지욱          최초 생성
 *  2011.08.26  서준식          EsntlId를 이용한 로그인 추가
 *  2014.12.08	이기하			암호화방식 변경(EgovFileScrty.encryptPassword)
 *  </pre>
 */
@Service("LoginService")
public class LoginServiceImpl extends EgovAbstractServiceImpl implements LoginService {

    
	@Resource(name="LoginMapper")
	private LoginMapper loginMapper;
	 
	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginServiceImpl.class);

    /**
	 * 일반 로그인을 처리한다
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    @Override
	public LoginVO actionLogin(LoginVO vo) throws Exception {
    	
    	// 2. 아이디와 암호화된 비밀번호가 DB와 일치하는지 확인한다.
    	LoginVO loginVO = loginMapper.actionLogin(vo);
    	
    	// 3. 결과를 리턴한다.
    	if (loginVO != null &&  loginVO.getUserId() !=null && !loginVO.getUserId().equals("")  ) {
    		return loginVO;
    	} else {
    		loginVO = null;
    	}

    	return loginVO;
    }
    

//	@Override
//	public LoginVO actionLogin(String userid, String password) throws Exception {
//		
//		LoginVO vo = new LoginVO();
//		vo.setUserId(userid);
//		vo.setUserId(password);
//		// TODO Auto-generated method stub
//		return actionLogin(vo);
//	}
//	

}
