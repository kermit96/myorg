package myorgwork.login.service;

import myorgwork.login.vo.LoginVO;



public interface LoginService {

	/**
	 * 일반 로그인을 처리한다
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exception
	 */
    LoginVO actionLogin(LoginVO vo) throws Exception;
    
    //LoginVO actionLogin(String userid,String password) throws Exception;
    
    //LoginVO actionLogin(String userid) throws Exception;
    
    
    
    //void updateLastLogin(LoginVO vo) throws Exception;
    

    //void  changeLang(LoginVO vo) throws Exception;;
    
    //public List<?> SubMenu(LoginVO vo) throws Exception;
    
    //public List<?> Topmenu(LoginVO vo) throws Exception;

	//void InsertSessionMenu(HttpServletRequest request,LoginVO userVO ) throws Exception;
	
}
