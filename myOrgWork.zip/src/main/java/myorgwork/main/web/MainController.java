package myorgwork.main.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import egovframework.rte.psl.dataaccess.util.EgovMap;
import myorgwork.login.vo.LoginVO;
import myorgwork.main.service.MainService;


@Controller
public class MainController {

	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(MainController.class);
	/** EgovLoginService */
	@Resource(name = "MainService")
	private MainService MainService;

	@RequestMapping(value = "/main.do")
	public String MainIndex() throws Exception {

		   // logService.InsertLog("MIS_MO_MAP_01", LogType.VIEW, "주요 모니터링", "주요 모니터링  조회");
			return "/main";
	}

	@RequestMapping(value = "/Main/SP_DEPT_TREE_S001.do",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String SP_DEPT_TREE_S001( String deptCd,
			HttpServletRequest request, HttpServletResponse response
			) throws Exception {

		List list ;

		list = MainService.SP_DEPT_TREE_S001(deptCd);

		Gson gson = new GsonBuilder().serializeNulls().create();
		return  gson.toJson(list).toString();
	}


	@RequestMapping(value = "/Main/SP_DEPT_TREE_S002.do",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String SP_DEPT_TREE_S002( String deptCd,
			HttpServletRequest request, HttpServletResponse response
			) throws Exception {

		List list ;

		try {
		list = MainService.SP_DEPT_TREE_S002(deptCd);

		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		Gson gson = new GsonBuilder().serializeNulls().create();
		return  gson.toJson(list).toString();
	}




}
