package myorgwork.main.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import myorgwork.login.vo.LoginVO;
import myorgwork.login.service.LoginService;
import myorgwork.main.service.MainService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 일반 로그인, 인증서 로그인을 처리하는 비즈니스 구현 클래스
 * @author 공통서비스 개발팀 박지욱
 * @since 2009.03.06
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자          수정내용
 *  -------    --------    ---------------------------
 *  2009.03.06  박지욱          최초 생성
 *  2011.08.26  서준식          EsntlId를 이용한 로그인 추가
 *  2014.12.08	이기하			암호화방식 변경(EgovFileScrty.encryptPassword)
 *  </pre>
 */
@Service("MainService")
public class MainServiceImpl extends EgovAbstractServiceImpl implements MainService {

    @Resource(name="MainMapper")
    private MainMapper mainMapper;
	/** log */
	private static final Logger LOGGER = LoggerFactory.getLogger(MainServiceImpl.class);
	@Override
	public HashMap GetData() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List SP_DEPT_TREE_S001(String deptCd) {
		// TODO Auto-generated method stub
		return mainMapper.SP_DEPT_TREE_S001(deptCd);
	}
	@Override
	public List SP_DEPT_TREE_S002(String deptCd) {
		// TODO Auto-generated method stub
		System.out.println("sp dept tree");
		return mainMapper.SP_DEPT_TREE_S002(deptCd);
	}

}
