package myorgwork.main.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import myorgwork.login.vo.LoginVO;

@Mapper("MainMapper")
public interface MainMapper {
	HashMap GetData(LoginVO vo);

	List SP_DEPT_TREE_S001(String deptCd);

	List SP_DEPT_TREE_S002(String deptCd);
}
