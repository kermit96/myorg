package myorgwork.main.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import myorgwork.login.vo.LoginVO;



public interface MainService {
    HashMap GetData();

	List SP_DEPT_TREE_S001(String deptCd);

	List SP_DEPT_TREE_S002(String deptCd);
}
