﻿function footerHtml(){
	var footer = ''; 
		footer += '<footer class="footerWrap">';
			footer += '<span>Copyrights&copy; 주식회사 한국정보공작소</span> <span>all right reserved.</span> <span class="tel">tel : 02.3667.3373 / 010.6476.8946</span>';
		footer += '</footer>';
		footer += '<div id="popSource" class="popModal_wrap"></div>';	 //   소스 코드 popup

	document.write(footer);
}
footerHtml();
