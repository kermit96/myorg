function EasyWrite(selector,saveLoc,fileSeq) {

	var opt = {};

	var now = new Date();


	var uploader = new fileUploader();
	uploader.setFileSeq(fileSeq);
    uploader.waitFileSeq(function() {

     opt.fileSeq= uploader.getFileSeq();


	 opt.fileKey= [ opt.fileSeq ];



    uploader.init({
			selector: selector,	//(필수) upload화일 선택 버튼 ID
    		saveLoc: saveLoc,			//(필수) upload화일 보관 위치
    		tempLoc: 'temp',			//(필수) upload화일 임시저장 위치
    		fileLoc: opt,			//(필수) 첨부화일 location info
    		sections:[
    			{
    				selector: selector+' #upload',									//(필수) upload화일 선택 버튼 ID
    				filter: ['.doc', '.docx', '.xls', '.xlsx','.zip', '.ppt', '.pptx', '.pdf', '.txt','.jpg','.png','.jpeg' ],	//(선택) 첨부화일 확장자 검사항목
    				pluginClass: listWriter,
    			},
    		],
    	});


    });


    return uploader;

}



function EasyReader(selector,saveLoc,fileSeq) {


	var opt = {};

	var now = new Date();


	var uploader = new fileUploader();
	uploader.setFileSeq(fileSeq);

	opt.fileSeq= uploader.getFileSeq();


	opt.fileKey= [ opt.fileSeq ];

   	uploader.init({
			selector: selector,	//(필수) upload화일 선택 버튼 ID
    		saveLoc: saveLoc,			//(필수) upload화일 보관 위치
    		tempLoc: 'temp',			//(필수) upload화일 임시저장 위치
    		fileLoc: opt,			//(필수) 첨부화일 location info
    		sections:[
    			{
    				selector: selector +" #upload",									//(필수) upload화일 선택 버튼 ID
    				filter: ['.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf', '.txt','.jpg','.png','.jpeg' ],	//(선택) 첨부화일 확장자 검사항목
    				pluginClass: listViewer,
    			},
    		],
   	});


}