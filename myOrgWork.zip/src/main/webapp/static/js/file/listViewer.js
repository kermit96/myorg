// 파일  list 보여주기
var listViewer = function(_caller) {
	var that= this;
	this._caller= _caller;
	var opt= null;
	var listCount= 0;
	this.listedFiles= [];
	this.deletedFiles= [];

	this.load = function (opt) {
		that.opt = opt;

		if(null == that._caller.opt.fileLoc.fileSeq) {
			loadData([]);
			return;
		}


    //  	MultiEmbeddedRtn(procedures, that._caller.opt.fileLoc, loadData, null );
    	AjaxSend("/file/FileList.do", {fileSeq: that._caller.opt.fileLoc.fileSeq},loadData  );
	}

    function loadData(ajaxdata) {
    	try {
    		var html= '';
			that.listedFiles= [];
			for(i in ajaxdata) {
				that.listedFiles.push(ajaxdata[i]);
				html += '<li><a id="name" href="#">'+ajaxdata[i].name+'</a></li>';
			}
			listCount= that.listedFiles.length;



			$(that.opt.selector).html(html);


			$($(that._caller.opt.selector+' a#name')).off('click');
			$($(that._caller.opt.selector+' a#name')).on('click',
					function(e){
				       that._caller.onDownload(e.target, that.listedFiles);
			    }

			);
    	} catch (ex) {
    		alert('listViewer.loadData:'+ex);
    	}
    }

	this.getCount = function () {
		return that.listedFiles.length;
	}

	this.getList = function () {
		return that.listedFiles;
	}

} //listViewer

