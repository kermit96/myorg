// list 보여주기
var listWriter = function(_caller) {
	var that= this;
	this._caller= _caller;
	var opt= null;

	this.load = function (opt) {
		that.opt = opt;

		if(null == that._caller.opt.fileLoc.fileSeq) {
			loadData([]);
			return;
		}


  //   	MultiEmbeddedRtn(procedures, that._caller.opt.fileLoc, loadData, null );

    	AjaxSend("/file/FileList.do", that._caller.opt.fileLoc,loadData  );
	}

    function loadData(ajaxdata) {
    	try {
			var listedFiles= [];
			for(i in ajaxdata)
				///if(null == filtering(ajaxdata.rows[i].name, size, extension))
					listedFiles.push(ajaxdata[i]);
			that.setList(listedFiles);
    	} catch (ex) {
    		alert('listWriter.loadData:'+ex);
    	}
    }

    this.setStyle = function () {
		/**
		$(that.opt.selector+' li.k-file div.file-wrapper .file-heading').css({display:"inline-block", float:"left" });
		$(that.opt.selector+' li.k-file div.file-wrapper .file-name-heading').css({"font-weight":"bold", "margin-top":"10px"});
		$(that.opt.selector+' li.k-file div.file-wrapper').css({position:"relative", height:"auto"});
		$(that.opt.selector+' li.k-file .file-wrapper .k-upload-action').css({position: "absolute", top: 0, right: 0});
		**/

		$(that._caller.opt.selector+' div.k-header').css({height:'120px', 'background-color':'#3d4853'});
		$(that._caller.opt.selector+' div.k-dropzone').css('height', '30px');
		$(that._caller.opt.selector+' li.k-file').closest('ul').css({"overflow-y": "scroll", height: "100px"});

		$(that._caller.opt.selector+' li.k-file a#name').off('click');
		$(that._caller.opt.selector+' li.k-file a#name').on('click', function(e){that._caller.onDownload(e.target, that.listedFiles);});
	}

    this.template = function (data/**/) {
		var $kendoOutput, $kendoHtmlEncode = kendo.htmlEncode;
		/**
		with(data){
			$kendoOutput=
				 '<span class="k-progress"></span>'
				+'<div class="file-wrapper">'
				+'    <h4 class="file-heading file-name-heading">'+(name)+'</h4>'
				+'	  <!--<span class="file-icon =addExtensionClass(files[0].extension)"></span>-->'
				+'	  <!--<h4 class="file-heading file-size-heading">Size: =size bytes</h4>-->'
				+'    <button type="button" class="k-upload-action"></button>'
				+'</div>\n';
		}
		**/
		with(data){
			$kendoOutput=
				 '<a id="name" href="#">'+(name)+'</a>'
				+'<!--Size: (size) bytes-->'
				+'<!--Extension: (files[0].extension)-->'
				+'<button type="button" class="k-upload-action" style="position: absolute; top: 0; right: 0;"></button>'
				+'\n';
			;
		}
		return $kendoOutput;
	}

} //listWriter

listWriter.prototype = new fileWriter();
