// 파일 업로드 기능
var fileUploader = function() {
	var that= this;
	this.opt= null;
	var fileSeq;

	this.init = function (opt) {
		console.log(opt);
		that.opt= opt;
		open();
	}

	function open () {
		var sec= that.opt.sections;
		for(i in sec) {
			if(null == sec[i].plugin)
				sec[i].plugin= new sec[i].pluginClass(that);
			sec[i].plugin.load(sec[i]);
		}
	}

	this.waitFileSeq = function (callback) {
		if(null != that.fileSeq) {
	        callback();
	        return;
	    }
//		EmbeddedRtn('MIS_CO.CO_FILE_SEQ',{}, function(e){ that.fileSeq= e.data[0].fileSeq; });

		AjaxSend("/file/getFileSeq.do",{},function(e) {

			 that.fileSeq = e;
		},"html");

		var timer = setInterval(function() {
		    if(null != that.fileSeq) {
		        clearInterval(timer);
				//console.log("Yes! Ready!");
		        callback();
		        return;
		    }
		}, 100);
	} //wait

	this.getFileSeq = function () {
		return that.fileSeq;
	}

	this.setFileSeq = function (seq) {
		that.fileSeq = seq;
	}



	this.getCount = function () {
		var sec= that.opt.sections;
		var count= 0;
		for(i in sec)
			count += sec[i].plugin.getCount();
		return count;
	}

	this.saveFiles = function (callback) {
		var sec= that.opt.sections;
		for(i in sec)
			sec[i].plugin.saveFiles(callback);

	//	if(null != callback)
	//		callback();
	}

	this.onDownload = function (e, listedFiles) {
		if($('#hidden_form').length == 0)
			$('body').append('<form id="hidden_form" name="hidden_form"></form>');

		if($('#hidden_frame').length == 0)
			$('body').append('<iframe align="center" name="hidden_frame" id="hidden_frame" frameborder="1" width="90%" height="0px" style="display:none;"></iframe>');

		var src= addSrc($(e).text(), listedFiles);
		console.log($(e).text()+','+src);

		var frm = document.hidden_form;
		frm.action = contextPath+'/file/downloadFile.do?filename='+encodeURIComponent($(e).text())+'&pathname='+encodeURIComponent(src);
		frm.method = "post";
		frm.target = "hidden_frame";
		frm.submit();
	}

	function addSrc (name, listedFiles) {
		if(listedFiles.length==0)
			return '#';



		for (var i=0;  i<listedFiles.length;i++) {
			if(listedFiles[i].fileOrgNm != name)
				continue;

			var pathName;
			var fileKey= that.opt.fileLoc.fileKey;


			if(null==listedFiles[i].fileSeq)
				pathName= '/'+that.opt.tempLoc;
			else
				pathName= '/'+that.opt.saveLoc;

			for (var j in fileKey)
				pathName+= '/'+fileKey[j];

			pathName+= '/'+name;

			console.log(pathName);

			return pathName;
		}
		return '#';
	}

} // fileUploader
