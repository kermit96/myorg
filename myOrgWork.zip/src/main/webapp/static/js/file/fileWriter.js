// 파일 upload
var fileWriter = function() {
	var that= this;
	this._super= null;
	this._caller= null;
	this.listedFiles= [];
	this.deletedFiles= [];
	var uploader= null;

	this.setList = function (files) {
		that._super= this;
		that._caller= that._super._caller;
		this.listedFiles= files;

		var comRetrieve = '찾아보기';	//찾아보기

		$(that._caller.opt.selector+' ul.k-upload-files').empty();
		$(that._caller.opt.selector+' div.k-dropzone').html('<div class="k-button k-upload-button"><input type="file" name="files" id="upload" data-role="upload" multiple="multiple" autocomplete="off"/><span>'+comRetrieve+'</span></div><em>drop files here to upload</em>');	//찾아보기

		that._super.uploader = $(that._super.opt.selector).kendoUpload({
			async: {
				saveUrl: contextPath+'/file/uploadFile.do?tempLoc='+that._caller.opt.tempLoc+'&fileKey='+encodeURIComponent(window.JSON.stringify(that._caller.opt.fileLoc.fileKey)),
				removeUrl: contextPath+'/file/deleteFileIgnore.do',
				//saveField: "customSaveField",
				//removeField: "customRemoveField",
				//batch: true,
				//autoUpload: true,
			},

			multiple: (null != that._caller.opt.sections[0].count ? false : true),
			select: onSelect,
			remove: onRemove,
			error: onError,
			success: onSuccess,
			cancel: onCancel,
			///complete: onComplete,
			///upload: onUpload,

			//validation: {
			//    allowedExtensions: [".jpg"],
			//    maxFileSize: 900000,
			//    minFileSize: 300000
			//},
			//enabled: false,
			//localization: {
				//select: "customSelect",
				//headerStatusUploaded: "customHeaderStatusUploaded"
			//},
			template: that._super.template,
			files: files,
		});

		that._super.setStyle();

		/**
		$("#getFiles").on('click', function(e){
		  e.preventDefault();

		  var upload = $("#files").data("kendoUpload"),
			  files = upload.getFiles();

		  alert("You have selected " + files.length  + " files");
		  console.log(files);
		});
		*/
	}

	this.getCount = function () {
		return that.listedFiles.length;
	}

	this.getList = function () {
		return that.listedFiles;
	}

	this.saveFiles = function (callback) {
		console.log('saving files!');

    	var param = {
    				 fileLoc:that._caller.opt.fileLoc, saveLoc:that._caller.opt.saveLoc, tempLoc:that._caller.opt.tempLoc,
    				 listedFiles:that._super.listedFiles, deletedFiles:that._super.deletedFiles};
    	console.log(param);

    /*
    	$.post(contextPath+'/file/saveFileUploaded.do',
			 'params='+encodeURIComponent(window.JSON.stringify(param)),

			function(data, status, xhr){
    			if(data.status=='error') {
    				alert(data.errMsg);
    				return;
    			}

				that._super.deletedFiles= [];
				console.log('save files complete!');
				if(null != callback)
					callback();
			}, 'json'
		).error(function(x,s,t) {httpError(x, s, t); });

	*/

    	AjaxSend(contextPath+'/file/saveFileUploaded.do',{
    		params:window.JSON.stringify(param)
    	},function(data) {


    		if(data.status=='error') {
				alert(data.errMsg);
				return;
			}

			that._super.deletedFiles= [];
			console.log('save files complete!');
			if(null != callback)
				callback();


    	},"json");



	}

	function onSelect (e) {
		console.log('onSelect');

	   $.each(e.files, function (index, value) {
			var errmsg= filtering(value.name, value.size, value.extension);

			if(null != errmsg) {
				e.preventDefault();
				alert('fileWriter.onSelect:'+errmsg);
				return;
			}
		});
	}

	function onSuccess (e) {
		var files = e.files;

		if (e.operation == "upload") {
			console.log("Successfully uploaded " + files.length + " files!");
			console.log(files);
			for(var i=0; i< files.length; i++)
				that._super.listedFiles[that._super.listedFiles.length]= files[i];

			that._super.setStyle();
		}
	}

	function onRemove (e) {
		var files = e.files;

		for(var i=0; i< files.length; i++) {
			console.log('onRemove ' + files.length + ' files! no:'+files[i].no+', name:'+files[i].name+', rawFile:'+files[i].rawFile);
			if(null == files[i].no && null == files[i].uid)
				continue;

			for(var j=0; j< that._super.listedFiles.length; j++)
				if(files[i].no != null && that._super.listedFiles[j].no == files[i].no
				|| files[i].uid != null && that._super.listedFiles[j].uid == files[i].uid
				) {
					///that._super.listedFiles[j].deleted= true;
					///if(files[i].no != null)
						that._super.deletedFiles[that._super.deletedFiles.length]= that._super.listedFiles[j];

					that._super.listedFiles= that._super.listedFiles.filter(function(e,idx,arr){return idx!=j;});
					that._super.setStyle();
					break;
				}
		}

		//e.preventDefault()
		return true;
	}

	function onCancel (e) {
		onRemove(e);
	}

	function onError (e) {
		// Array with information about the uploaded files
		var files = e.files;
		if (e.operation == "upload")
			alert("fileWriter.onError:Failed to upload " + files.length + " files");
	}

	function onUpload (e) {
		console.log('onUpload');
		///e.sender.opt.async.saveUrl = '/COMM/uploadFile.do?saveLoc='+that._caller.tempLoc+'/'+that._caller.opt.fileKey;
	}

	function onComplete (e) {
		console.log('onComplete');
	}

	this.getCount = function () {
		return that._super.listedFiles.length;
	}

	this.getList = function () {
		return that._super.listedFiles;
	}

	function filtering (name, size, extension) {
		console.log("Name: " + name);
		console.log("Size: " + size + " bytes");
		console.log("Extension: " + extension);

		var filter= that._super.opt.filter;
		if(null == filter)
			filter= [];

		var i;
		for(i=0; i < filter.length; i++) {
			if (extension.toLowerCase() == filter[i])
				break;
		}

		if(filter.length > 0 && i == filter.length)
			return (extension+' files can not be uploaded!');

		///if(parseInt(size) > 20971520)
		///	return (name+' file was exceeded 20MB size limit!');

		for(i in that._super.listedFiles) {
			if(name == that._super.listedFiles[i].name)
				return (name+' file was already selected!');
		}

		return null;
	} //filtering

} //fileWriter

