﻿function Header(){
	var header = ''; 
		header += '<link rel="stylesheet" type="text/css" href="../static/plugins/kendo/styles/kendo.common-material.min.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/plugins/kendo/styles/kendo.material.min.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/plugins/kendo/styles/kendo.rtl.min.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/css/webfont.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/css/reset.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/css/common.css" />';
		header += '<link rel="stylesheet" type="text/css" href="../static/css/content.css" />';

		header += '<script src="../static/js/jquery.min.js"></script>';
		header += '<script src="../static/plugins/kendo/js/jszip.min.js"></script>';
		header += '<script src="../static/plugins/kendo/js/kendo.all.min.js"></script>';
		header += '<script src="../static/plugins/kendo/js/cultures/kendo.culture.ko-KR.js"></script>';
		header += '<script src="../static/plugins/kendo/js/cultures/kendo.culture.en-US.js"></script>';
		header += '<script src="../static/plugins/kendo/js/cultures/kendo.culture.zh-CN.js"></script>';
		header += '<script src="../static/plugins/kendo/js/cultures/kendo.culture.ja-JP.js"></script>';
		header += '<script src="../static/plugins/kendo/js/messages/kendo.messages.ko-KR.js"></script>';  
		header += '<script src="../static/plugins/amcharts/amcharts.js"></script>';
		header += '<script src="../static/plugins/amcharts/serial.js"></script>';
		header += '<script src="../static/js/jquery.jscrollpane.min.js"></script>';
		header += '<script src="../static/js/jquery.panzoom.js"></script>';
		header += '<script src="../static/js/jquery.mousewheel.js"></script>';
		header += '<script src="../static/js/content.js"></script>';

	document.write(header);
}
Header();
