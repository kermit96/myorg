$(function(){
	
	initGnbNavi();
	
	// 메뉴 기능
	function initGnbNavi(){
		gnbMenuMouseEvent();
		showMenu();
		hideMenu();
	}
	
	
	function showMenu(num) {
		var currentMenu = $('.navi .title').eq(num);//현재 선택된 메뉴
		var currentNaviDept = $('.navi_depth').eq(num);//현재 선택된 메뉴
	
		//선택된 메뉴와 나머지 메뉴들 이미지 롤오버
		$('.depth_group > ul').removeClass('on');
		$('.depth_align > ul').eq(num).addClass('on');
		
		//선택된 메뉴와 나머지 메뉴들 이미지 롤오버
		$('.navi .title').removeClass('on');
		$('.navi .title').eq(num).addClass('on');
	
	}
	
	function hideMenu(num) {
		var currentNaviDept = $('.navi_depth').eq(num);//현재 선택된 메뉴
	
		//선택된 메뉴와 나머지 메뉴들 이미지 롤오버
		$('.depth_group > ul').eq(num).addClass('on');
		$('.depth_align > ul').removeClass('on');
		
		//선택된 메뉴와 나머지 메뉴들 이미지 롤오버
		$('.navi .title').eq(num).addClass('on');
		$('.navi .title').removeClass('on');
	
	}
	
	
    
	
	function gnbMenuMouseEvent(){
		var gnbMenuEle = $(".navi .title");
		var gnbNaviDepthEle = $(".navi_depth");
		
		var gnbNaviDepthEleUi = $(".depth_ul");
		
		gnbMenuEle.mouseenter(function(){
			
			var index = gnbMenuEle.index(this);
			var depthUl = $(".depth_group");
			depthUl.show();
			//setGnbTrianglePosition(ele);

			gnbNaviDepthEle.stop().slideDown( 300, function() {
				// Animation complete.
			});
			
			
			$(this).addClass("on");
			var connectMenu = $(this).index(); //a 부모 li의 인덱스(순서)
			showMenu(connectMenu);
			
		});
		
		$("#navi_group").mouseenter(function(){
			
			var index = gnbMenuEle.index(this);
			var depthUl = $(".depth_group");
			depthUl.show();
			//setGnbTrianglePosition(ele);

			gnbNaviDepthEle.stop().slideDown( 300, function() {
				// Animation complete.
			});
			
		});
		

		$("#navi_group").mouseleave(function(){
			var index = gnbMenuEle.index(this);
			//gnbNaviDepthEle.hide();
			
			gnbNaviDepthEle.stop().slideUp( 300, function() {
				// Animation complete.
			});
			
		});
		
		gnbMenuEle.mouseover(function(){
			$(this).addClass("on");
		});
		
		gnbMenuEle.mouseout(function(){
			$(this).removeClass("on");
			var connectNaviDept = $(this).index();// a 부모 li의 인덱스(순서)
			hideMenu(connectNaviDept);
		});
		
		gnbNaviDepthEleUi.mouseover(function(){
			$(this).addClass("on");
			var connectNaviDept = $(this).index();// a 부모 li의 인덱스(순서)
			showMenu(connectNaviDept);
		});
		
		gnbNaviDepthEleUi.mouseout(function(){
			$(this).removeClass("on");
			var connectNaviDept = $(this).index();// a 부모 li의 인덱스(순서)
			hideMenu(connectNaviDept);
		});

	}
	
	//changeGnbScrollVersion();
	$(window).scroll(function(){
		var scrollTop = $(window).scrollTop();
		if(scrollTop==0){
			changeGnbDefaultVersion();
		}else{
			changeGnbScrollVersion();
		}

		/*scrollQuickMenu();*/

		var header = $("#header");
		var scrollLeft = $(window).scrollLeft();
		header.css("left",-scrollLeft + "px");
	});
	function changeGnbDefaultVersion(){
		var gnb = $(".gnb");
		//gnb.removeClass("scroll");
	}

	function changeGnbScrollVersion(){
		var gnb = $(".gnb");
		//gnb.addClass("scroll");
	}
	// 메뉴기능 끝
	

	
});



$(function () {
	
    /* 언어 선택 */
    $('.util .global span a').bind('mouseenter focusin', function () {
        $('.language-selector', this.parentNode.parentNode).stop().animate({ 'height': $('ul li', this.parentNode.parentNode).length * ($('ul li', this.parentNode.parentNode).height() + 30) });
    });
    $('.language-selector, .global').bind('mouseleave focusout', function () {
        $(this).data('timer', setTimeout(function () {
            $('.language-selector').stop().animate({ 'height': '0px' });
        }, 200));
    }).bind('mouseenter focusin', function () {
        if ($(this).data('timer')) {
            clearTimeout($(this).data('timer'));
        }
    });

});

 
// 파라메터 정보가 저장될 오브젝트
// common.js 같은 모든 페이지에서 로딩되는 js 파일에 넣어두면 됨.
  function getParam (key){
    var _parammap = {};
    document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
        function decode(s) {
            return decodeURIComponent(s.split("+").join(" "));
        }

        _parammap[decode(arguments[1])] = decode(arguments[2]);
    });

    if (typeof _parammap[key] != "undefined") {
       return _parammap[key];
    }
    
    return "";
 }
  // 
  //  YYYYMM 형식으로 보내준다 
  //  예) 
  //   dateToYYYYMM(date)
  //  199906
  function dateToYYYYMM(date) {
	  var yyyy = date.getFullYear();
	  var mon = date.getMonth()+1;
	  if (mon>9) {
		  return yyyy+""+mon;
	  } else {
		  return yyyy+""+"0"+mon;
	  }
	  
  }
  
  
  // 현재 년도 . yyyYY =>2015
  function dateToYYY(date) {
	  var yyyy = date.getFullYear();
	  
	  return yyyy;
  }
  
  
  // 현재 년도 . YY =>15
  function getYear() {
	  
	  var date = new Date();
	  return date.getFullYear();
  }
  
  // 
  //  YYYYMM 형식으로 보내준다 
  //  예) 
  //   dateToYYYYMM(date)
  //  1999.06
  
  function dateToYYYYMM2(date) {
	  var yyyy = date.getFullYear();
	  var mon = date.getMonth()+1;
	  if (mon>9) {
		  return yyyy+"."+mon;
	  } else {
		  return yyyy+"."+"0"+mon;
	  }
	  
  }
   
  // kendo datepicket 에서  년 가져오기 . 
  // 2015 년 이면 15 식으로 가져온다 
  function getYearDatePicker(datepickerid) {

	  var id = "#"+datepickerid;
	   id = id.replace("##","#");
	  var datepicker = $(id).data("kendoDatePicker");		
	  var date = datepicker.value();
	  var yyyy = date.getFullYear()-2000;	    
	  return yyyy;
	  
  } 
  
  
  // kendo datepicket 에서  월 가져오기  
  function getMonthDatePicker(datepickerid ) {


	  var id = "#"+datepickerid;
	  
	   id = id.replace("##","#");
	  var datepicker = $(id).data("kendoDatePicker");
	  	  		
	  var date = datepicker.value();

	  var month = date.getMonth()+1;	  
	  return month;
	  
  }

  
  // kendo combobox Text 가져오기 
  function getComboxBoxText( comboboxid ) {
	  
	  var id = "#"+comboboxid;
	  
	   id = id.replace("##","#")
	  
	  var combobox = $(id).data("kendoComboBox");		

      return combobox.text();
	  
	  
  }
 
  
  // kendo combobox 값 가져오기 
  function getComboxBoxValue(comboboxid ) {
	  
	  var id = "#"+comboboxid;
	  
	   id = id.replace("##","#")
	  
	  var combobox = $(id).data("kendoComboBox");		

      return combobox.value();
	  
	  
  }
 
  
  // 숫자 인지 아닌지 check 
  function isNumeric(num, opt){
	  num = String(num).replace(/^\s+|\s+$/g, "");
	  if(typeof opt == "undefined" || opt == "1"){
	    var regex = /^[+\-]?(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+){1}(\.[0-9]+)?$/g;
	  }else if(opt == "2"){
	    var regex = /^(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+){1}(\.[0-9]+)?$/g;
	  }else if(opt == "3"){
	    var regex = /^[0-9]+(\.[0-9]+)?$/g;
	  }else{
	    var regex = /^[0-9]$/g;
	  }
	  if( regex.test(num) ){
	    num = num.replace(/,/g, "");
	    return isNaN(num) ? false : true;
	  }else{ return false;  }
	}
	 
  // 숫자 인지 check 
	function getNumeric(str, opt){
	  if(isNumeric(str, opt)){
	    str = String(str).replace(/^\s+|\s+$/g, "").replace(/,/g, "");
	    return Number(str);
	  }else{
	    return str;
	  }
	}
	 
	// 컴마 출력
	function AddComma(data_value) {
		
		if (data_value == undefined ) 
			return "";
         if (isNumeric(data_value)== false)
        	 return data_value;
     //    alert(data_value);
    // 	return Number(data_value).toLocaleString('en');
        return data_value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

	}
	
	// 컴마 출력
	function AddComma2(data_value) {

		if (data_value == undefined ) 
			return "";
		
		if (data_value>0) { 
			return "+"+data_value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		} else { 
	    	return data_value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		}
	}
	
	//숫자 컴마(0인경우 공백리턴)
	function AddCommaZeroToNull(data_value) {
		
		if (data_value == undefined || data_value == 0) 
			return "";
		if (isNumeric(data_value)== false)
			return data_value;
	     
        return data_value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

	}
	
	
	// 반롤림하고 comma 출력
	function RoundComma(val, point, needComma, needBlank) {
		if (val == undefined ) 
			return "";
		if (isNumeric(val)== true) {
			if(isNaN(Number(val)))
				 return val;
			val= Number(val);
		}
		
		if(val<0)
			return val;
		if(val==0 && needBlank)
			return '';

		val= val.toFixed(point);
		if(!needComma)
			return val;
		
		return val.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	}

	String.prototype.format = function() {
		var formmatedValue = this;
		for (var i = 0; i < arguments.length; i++) {
			var replaceRegex = new RegExp("\\{" + i + "\\}", "gm");
			formmatedValue = formmatedValue.replace(replaceRegex, arguments[i]);
		}
		return formmatedValue;
	}

	/*서버오류 메시지 알림창*/
	function httpError(x, s, t) {
		try {eval('var d = ' + x.responseText);
			if (x.status=='406') {
				alert('common.httpError:'+ d.massage ? d.massage : d.status);
			}
		} catch(e) {
			alert('common.httpError:정상적으로 처리되지 못했습니다. (ERROR_CODE: ' + x.status + ')');
		}
	}

	// per에 따라서 처리 
	// 100% 이상이면 파란색 
	// 90~ 99 이면 노란색 
	// 90 미만 이면 빨간색 
	function percentColor(id,per) {
		if (per <90) {
			$("#"+id).css("color", "#d60000");  //빨간색
			return; 
		}
		if (per>=90 &&  per<100 ) {
			$("#"+id).css("color", "#c87202");  //노란색
	//		$("#"+id).css("color", "yellow");  //노란색

			return; 
		}
		$("#"+id).css("color", "#0074b4");  //파란색
	//	$("#"+id).css("color", "blue");  //파란색
	}
	
// Ajax 준비 	
function SetAjaxWait()
{
	  $(document).ajaxStart(
			  function () {
				    $('body').css('cursor', 'wait');
				}
	  ).ajaxStop(
			  function () {
				    $('body').css('cursor', 'auto');
				}	  
	  );
}


// table 에 msis_table_custom class 로 변경한다.
function ReplaceTableClass(data)
{
	 return  data.replace(/<[\s]*table[\s]+[^>]*>|<table>/gim,"<table class=\"msis_table_custom\">");

}

// 분리할 글자가 있는지 check 
function IsSplitData(data,column,splitstr,max) {
	
	if (max ==undefined) 
		max = data.length+1; 
	
	if (data.length <max+1) {		
		return false;
	}
	
	for(var i=0;i<data.length;i++) {
		if (i==0)
			continue;
		if (data[i][column] == null)
			continue;
		if (data[i][column].indexOf(splitstr) >=0 )
			return true;
		
	}
	
	return false;
}


//ajax 호출
function AjaxSend(url,senddata,callback,dataType) {
	
	if ( dataType == undefined || dataType == null  || dataType == "" ) {
		
		dataType = "json";
	}
	
	 try {
	       $.ajax({
	           url:url,
	           type:'post',
	           dataType:dataType,
	           cache:false,
	           data:senddata,
	           success:function(data){
	        	   callback(data);
	           },
	           error:function(request,status,error){
	                alert("common.AjaxSend:code:"+request.status+"n\n"+"message:"+request.responseText+"\n"+"error:"+error);
	              }
	           	                                    
	       });
			
	       } catch (ex) {        	
	       	alert("common.AjaxSend:ajax="+ex);
	       }
	
}





/*********************** 파일업로드 ***********************/

/*'use strict'; 

;( function ( document, window, index )
{
	var inputs = document.querySelectorAll( '.inputfile' );
	Array.prototype.forEach.call( inputs, function( input )
	{
		var label	 = input.nextElementSibling,
			labelVal = label.innerHTML;

		input.addEventListener( 'change', function( e )
		{
			var fileName = '';
			if( this.files && this.files.length > 1 )
				fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
			else
				fileName = e.target.value.split( '\\' ).pop();

			if( fileName )
				label.querySelector( 'span' ).innerHTML = fileName;
			else
				label.innerHTML = labelVal;
		});

		// Firefox bug fix
		input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
		input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
	});
}( document, window, 0 ));*/


//post 로 url 호출
function doPost(url, params) {
	if($('#hidden_form').length == 0)
		$('body').append('<form id="hidden_form" name="hidden_form"></form>');

	var frm = document.hidden_form;
	frm.action = contextPath+url;
	$(frm).empty();
	for(var i=0; i < params.length; i++)
		$(frm).append("<input type=hidden name='"+params[i].name+"' value='"+params[i].val+"'/>");
	frm.method = "post";
	frm.target = "_self";
	frm.submit();
}

// popup window 올리기 
function popPost(url, winparam, params) {
	if($('#hidden_form').length == 0)
		$('body').append('<form id="hidden_form" name="hidden_form"></form>');

	var frm = document.hidden_form;
	window.open('', 'hidden_form', winparam);
	frm.action = contextPath+url;
	$(frm).empty();
	for(var i=0; i < params.length; i++)
		$(frm).append("<input type=hidden name='"+params[i].name+"' value='"+params[i].val+"'/>");
	frm.method = "post";
	frm.target = "hidden_form";
	frm.submit();
} 

/**
 * 쿠키값 추출
 * @param cookieName 쿠키명
 */
function getCookie( cookieName )
{
 var search = cookieName + "=";
 var cookie = document.cookie;

 // 현재 쿠키가 존재할 경우
 if( cookie.length > 0 )
 {
  // 해당 쿠키명이 존재하는지 검색한 후 존재하면 위치를 리턴.
  startIndex = cookie.indexOf( cookieName );

  // 만약 존재한다면
  if( startIndex != -1 )
  {
   // 값을 얻어내기 위해 시작 인덱스 조절
   startIndex += cookieName.length;

   // 값을 얻어내기 위해 종료 인덱스 추출
   endIndex = cookie.indexOf( ";", startIndex );

   // 만약 종료 인덱스를 못찾게 되면 쿠키 전체길이로 설정
   if( endIndex == -1) endIndex = cookie.length;

   // 쿠키값을 추출하여 리턴
   return unescape( cookie.substring( startIndex + 1, endIndex ) );
  }
  else
  {
   // 쿠키 내에 해당 쿠키가 존재하지 않을 경우
   return "";
  }
 }
 else
 {
  // 쿠키 자체가 없을 경우
  return "";
 }
}



/**
 * 쿠키 설정
 * @param cookieName 쿠키명
 * @param cookieValue 쿠키값
 * @param expireDay 쿠키 유효날짜
 */
function setCookie( cookieName, cookieValue, expireDate )
{
	 var today = new Date();
	 today.setDate( today.getDate() + parseInt( expireDate ) );
	 document.cookie = cookieName + "=" + escape( cookieValue ) + "; path=/; expires=" + today.toGMTString() + ";";
}



/**
 * 쿠키 삭제
 * @param cookieName 삭제할 쿠키명
 */
function deleteCookie( cookieName )
{
 var expireDate = new Date();
 
 //어제 날짜를 쿠키 소멸 날짜로 설정한다.
 expireDate.setDate( expireDate.getDate() - 1 );
 document.cookie = cookieName + "= " + "; expires=" + expireDate.toGMTString() + "; path=/";
}

// percent 값 출력
function MakePercentDraw(id,data,colname,width) {
	MakePercentDraw_item(id,data,colname,width);
	MakePercentDraw_item(id,data,colname,width);
}

function MakePercentDraw_item(id,data,colname,width)
{  
	var length = data.length;
	var margin = width/length-$(".chartTopValue").width();
	var firstmargin = margin/2;	//margin-20
	var secondmargin = margin-5;
	if (firstmargin<0)
		firstmargin = 0;
	if (secondmargin<0)
		secondmargin = 0;
	 	
	if (margin <=20)
	  secondmargin += 2.5;
	if (margin >20 && margin <=30)
		  secondmargin += 2.2;
	if (margin >30 && margin <=50)
		  secondmargin += 2.1;
	if (margin >50 && margin <60 )
		secondmargin += 2;
	var size = 0;
	if(length > 1)
		size= (width-$(".chartTopValue").width())/length;

	var html = "";
	var str;
	var showdata = [];
	
	for(var i=0;i<length;i++) {
		if(0==size)
			str = "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px; {1}\">{2}</div>"; 
		else
			str = "<div class=\"chartTopValue\" style=\" margin:0px 0px 0px {1}px; {2}\">{3}</div>"; 
		var margin ="";
		if (i == 0)
			margin = firstmargin;
		else
			margin = secondmargin;
		
		var labelWidth = size - secondmargin;
		
		/*
		if(labelWidth < 40)
			labelWidth= 40;
		if (labelWidth > 60)
			labelWidth =  60;
			*/
		
		labelWidth = $(".chartTopValue").width();
		
		
		
		
		if(0==size && null==data[i][colname])
			html += str.format(margin, 'background-color:#475460; border:0px;', '');
		else if(0==size && null!=data[i][colname])
			html += str.format(margin, '', data[i][colname]+'%');
		else if(null==data[i][colname])
			html += str.format(labelWidth,margin, 'background-color:#475460; border:0px;', '');
		else if(null!=data[i][colname])
			html += str.format(labelWidth,margin, '', data[i][colname]+'%');
	}
	
	$(id).html(html);
	
}

//2개 percent 값 출력  
function MakePercentDrawBoth(id,data,colname,colname2,width){
	MakePercentDrawBoth_Item(id,data,colname,colname2,width);
	MakePercentDrawBoth_Item(id,data,colname,colname2,width);
}

function MakePercentDrawBoth_Item(id,data,colname,colname2,width)
{  
	id = "#"+id;
	id = id.replace("##","#");
	
	var showdata = [];
	
	for(i=0;i<data.length;i++) {
		var tempdata = {};
		
		tempdata[colname] = data[i][colname];
		tempdata[colname2] = data[i][colname2];
	
		if (data[i][colname] == null) 
			tempdata[colname] = 0;
		if (data[i][colname2] == null) 
			tempdata[colname2] = 0;
	  
		showdata.push(tempdata);
		 
	}
	
	var length = data.length;
	
	var chartTopWidth = $(".chartTopValue").width();
	
	chartTopWidth = 40;
	var margin = width/length;
	
	var firstrate = 5;
	
	if (length ==4)
		firstrate = 5;
	if (length ==3)
		firstrate = 10;
	
	if (length ==2)
		firstrate = 15;
	
	if (length ==1)
		firstrate = 20;
	
	if (length ==6)
		firstrate = 2;
	
	if (length ==7)
		firstrate = 0.5;
	if (length ==8)
		firstrate = 0.4;
	
	if (length ==9)
		firstrate = 0.3;
	
	if (length ==10)
		firstrate = 0.2;
	
	if (length ==11)
		firstrate = 0.1;
	
	if (length>10)
		firstrate = 1/length;
	
	var firstmargin = margin/2-chartTopWidth*2-length*firstrate;	//margin-20
	var secondmargin = margin/3*3-chartTopWidth*3.4;
	
	secondmargin2 = 10;
	if (secondmargin<=0) {
		secondmargin = 10;
		secondmargin2 = 5;
	}

	
	
	var html = "";
	for(var i=0;i<length;i++) {
		var str = "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px;width=40px\">{1}%</div>"; 
		var margin =0;
		if (i ==0 ) {
			margin = firstmargin;
			 
		} else if(i==1) {
			margin = secondmargin;
		} else {
			margin = secondmargin; 
			
		}
		html += str.format(margin,replaceAll(showdata[i][colname].toString(),"%",""));
		html += str.format(10,replaceAll(showdata[i][colname2].toString(),"%",""));
		
	}
			
	$(id).html(html);
	
}

//percent 값 출력
function MakePercent(id,data,colname,width)
{
	MakePercentItem(id,data,colname,width);
	MakePercentItem(id,data,colname,width);
	
}

function MakePercentItem(id,data,colname,width)
{
	var length = data.length;
	var margin = width/length-$(".chartTopValue").width();
	var firstmargin = margin/2;	//margin-20
	var secondmargin = margin-5;
	if (firstmargin<0)
		firstmargin = 0;
	if (secondmargin<0)
		secondmargin = 0;
  
	var size = 0;
	if(length > 1)
		size= (width-$(".chartTopValue").width())/length;

	var html = "";
	var str;
	var showdata = [];
	
	for(var i=0;i<length;i++) {
		if(0==size)
			str = "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px; {1}\">{2}</div>"; 
		else
			str = "<div class=\"chartTopValue\" style=\"width:{0}px; margin:0px 0px 0px {1}px; {2}\">{3}</div>"; 
		var margin ="";
		if (i == 0)
			margin = firstmargin;
		else
			margin = secondmargin;
		
		var labelWidth = size - secondmargin;
		if(labelWidth < 50)
			labelWidth= 50;
		if (labelWidth > 60)
			labelWidth =  60;
		
		if(0==size && null==data[i][colname])
			html += str.format(margin, 'background-color:#475460; border:0px;', '');
		else if(0==size && null!=data[i][colname])
			html += str.format(margin, '', data[i][colname]+'%');
		else if(null==data[i][colname])
			html += str.format(labelWidth,margin, 'background-color:#475460; border:0px;', '');
		else if(null!=data[i][colname])
			html += str.format(labelWidth,margin, '', data[i][colname]+'%');
	}
	
	$(id).html(html);
	$(id).css('chartTopValueSet');
}

//percent 값 출력
function MakePercent1(id,data,colname,width)
{
	MakePercentItem1(id,data,colname,width);
	MakePercentItem1(id,data,colname,width);
}

function MakePercentItem1(id,data,colname,width)
{  
	var showdata = [];
	
	for(i=0;i<data.length;i++) {
		var tempdata = {};
		
		tempdata[colname] = data[i][colname];
	
		//if (data[i][colname] == null) 
		//	tempdata[colname] = 0;
	
		showdata.push(tempdata);
		
	}
	
	var length = data.length;
	
	var margin = width/length-$(".chartTopValue").width();

	
	var firstmargin = margin/2;
	
	var secondmargin = margin-5;
	
	if (firstmargin<0)
		firstmargin = 0;
	
	if (secondmargin<0)
		secondmargin = 0;
	
			
	var html = "";
	for(var i=0;i<length;i++) {
		var margin ="";
		if (i ==0 ) {
			margin = firstmargin;
			
		} else {
			margin = secondmargin;
		}
		if(null==showdata[i][colname])
			html += "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px; background-color:#475460; border:0px;\"></div>".format(margin);
		else
			html += "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px;\">{1}</div>".format(margin, showdata[i][colname]+'%');
	}
			
	$(id).html(html);
	
}

//percent 값 출력
function MakePercentText(id,data,colname,width,text)
{
	MakePercentTextItem(id,data,colname,width,text);
	MakePercentTextItem(id,data,colname,width,text);
}

// percent 값 출력

function MakePercentTextItem(id,data,colname,width,text)
{
	var length = data.length;
	var margin = width/length-$(".chartTopValue").width();
	var firstmargin = margin/2;	//margin-20
	var secondmargin = margin-5;
	if (firstmargin<0)
		firstmargin = 0;
	if (secondmargin<0)
		secondmargin = 0;
  
	var size = 0;
	if(length > 1)
		size= (width-$(".chartTopValue").width())/length;

	var html = "";
	var str;
	var showdata = [];
	
	for(var i=0;i<length;i++) {
		if(0==size)
			str = "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px; {1}\">{2}</div>"; 
		else
			str = "<div class=\"chartTopValue\" style=\"width:{0}px; margin:0px 0px 0px {1}px; {2}\">{3}</div>"; 
		var margin ="";
		if (i == 0)
			margin = firstmargin;
		else
			margin = secondmargin;
		
		var labelWidth = size - secondmargin;
		if(labelWidth < 50)
			labelWidth= 50;
		if (labelWidth > 60)
			labelWidth =  60;
		
		if(0==size && null==data[i][colname])
			html += str.format(margin, 'background-color:#475460; border:0px;', '');
		else if(0==size && null!=data[i][colname])
			html += str.format(margin, '', data[i][colname]+'%');
		else if(null==data[i][colname])
			html += str.format(labelWidth,margin, 'background-color:#475460; border:0px;', '');
		else if(null!=data[i][colname])
			html += str.format(labelWidth,margin, '', data[i][colname]+text);
	}
	
	$(id).html(html);
	$(id).css('chartTopValueSet');
}

//count 값 출력 
function MakeCount(id,data,colname,width)
{
	var length = data.length;
	var margin = width/length-$(".chartTopValue").width();
	var firstmargin = margin/2;	//margin-20
	var secondmargin = margin-5;
	if (firstmargin<0)
		firstmargin = 0;
	if (secondmargin<0)
		secondmargin = 0;
		 	
	var size = 0;
	if(length > 1)
		size= (width-$(".chartTopValue").width())/length;

	var html = "";
	var str;
	for(var i=0;i<length;i++) {
		if(0==size)
			str = "<div class=\"chartTopValue\" style=\"margin:0px 0px 0px {0}px; {1}\">{2}</div>"; 
		else
			str = "<div class=\"chartTopValue\" style=\"width:{0}px; margin:0px 0px 0px {1}px; {2}\">{3}</div>"; 
		var margin ="";
		if (i ==0)
			margin = firstmargin;
		else
			margin = secondmargin;
		
		var labelWidth = size - secondmargin;
		if(labelWidth < 40)
			labelWidth= 40;
		if (labelWidth > 60)
			labelWidth =  60;

		if(0==size && null==data[i][colname])
			html += str.format(margin, 'background-color:#475460; border:0px;', '');
		else if(0==size && null!=data[i][colname])
			html += str.format(margin, '', data[i][colname]);
		else if(null==data[i][colname])
			html += str.format(labelWidth,margin, 'background-color:#475460; border:0px;', '');
		else if(null!=data[i][colname])
			html += str.format(labelWidth,margin, '', data[i][colname]);
	}
	
	$(id).html(html);
	$(id).css('chartTopValueSet');
}


// Label 만들기
function MakeLabel(id,text)
{
	var html;
	if(text == "") {
		
		html = '<div class="titDep0">'+"&nbsp;"+'</div>';
	} else {
	  html = '<div class="titDep2 disInBl">'+text+'</div>';
	}
			
	$(id).html(html); 
	$(id).css('chartTopValueSet mar0');
}

//데이타 Set 을  Array 로 변경 
function DataSetToList(data,coloum,addword) {
	if (addword == undefined  )
		addword = "";
	var headlist = [];
	for(var i=0;i< data.length;i++) {
		var viewcolname = "";
		if (data[i][coloum] != undefined ) {
			
			viewcolname =data[i][coloum]; 
		}  
		
    	  headlist.push(viewcolname+addword);    	  
    }		
	return headlist;
}

//데이타 값   분리하고  중간에 <br> 추가 
function DataSetToListSplit(data,coloum,addword,split,maxnum) {
	if (addword == undefined  )
		addword = "";
	if (split == undefined  )
		split = "";
	
	var max = 0;
	
	if (maxnum == undefined)
		max = data.length;
	
	var headlist = [];
	var isSplit = false;
	if (max < data.length) 
		isSplit = true;
	
	for(var i=0;i< data.length;i++) {
		var viewcolname = data[i][coloum];
		if (data[i][coloum] != null && isSplit == true ) {
		
			viewcolname =data[i][coloum];
			viewcolname = replaceAll(viewcolname,split,"\n");
			viewcolname =viewcolname +addword ; 
		}  
		
    	headlist.push(viewcolname);    	  
    }		
	return headlist;
}


// 데이타 값   분리하고  중간에 <br> 추가    
function DataSetToListBr(data,coloum,addword,limit) {
	if (addword == undefined  )
		addword = "";
	if (limit == undefined) 
		limit = 12;
	
	var headlist = [];
	for(var i=0;i< data.length;i++) {
		var viewcolname = "";
		if (data[i][coloum] != undefined ) {
			
			viewcolname =data[i][coloum]; 
		}  
		
		viewcolname = viewcolname+addword;
		
		if(data.length>limit) {
	   		
    			if(i%2==1){
    				viewcolname = "&nbsp;\n"+viewcolname;	
    			}
    		
			
		}
		
    	headlist.push(viewcolname);    	  
    	  
    	  
    }		
	return headlist;
}






// 임의의  커럴 값 가져오기 
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}  	


// 라디오 버튼  text 가져 오기 
function RadioButtonText(name) {
	
	
	return $("input[name="+name+"]:checked").text();
		
	
}

//라디오 버튼  select  
function RadioButtonSelect(name,cd) {
	
	var list = $('input:radio[name='+name+']');
	for(var idx in list)
		if(list[idx].value == cd) {
			list[idx].checked = true;
			return;
		}
	
}

//라디오 버튼  값 가져오기 
function RadioButtonValue(name) {
	
	
	return $("input[name="+name+"]:checked").val();
		
	
}

//radio button 0번쨰를 check 하게 한다.   
function RadioButtonFirstCheck(name) {
   	 var count =0;
	 $('[name='+name+']').each(function() {
      if (count == 0 ) {
    	 this.checked = true;
      }
	  count++;

  });        	      	
}

function RadioButtonCheckCount(name,num) {
	 var count =0;
	 $('[name='+name+']').each(function() {
      if (count == num ) {
    	 this.checked = true;
      } else {
    	  this.checked = false;
      }
	  count++;

  });
	
}

function FillRadioButton(data,radiobuttonname,spanname,onchange) {
	
	var radioarray = $("[name="+radiobuttonname+"]");
	var spanarray =  $("[name="+spanname+"]");
	
	for(var i=0;i<data.length;i++) {
		if (radioarray.length== i) 
			break;
		$(radioarray[i]).val(data[i].cd);
		$(spanarray[i]).text(data[i].cdNm);
	}
	
	$("[name="+radiobuttonname+"]").on('change', function(){		
		onchange($(this).val());
	});
	
}

//같은  값이 있는 row 를 병합시킨다.
//n,n-1,n-2 column 을 병합시키다.

function TableColMerge1(id,colnum,showtableindex) {
	
		
	if (showtableindex == undefined)
		showtableindex = 0;
	
	$(id+' tbody:eq('+showtableindex +")").each(function() {		

		var table = $(this).parent();
		
		$.each([colnum] /* 합칠 칸 번호 */, function(c, v) {
			var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
			for(j = 1; j < tds.length; j ++) {
				if(tds[i].innerHTML != tds[j].innerHTML) {
					$(tds[i]).attr('rowspan', j - i);
					i = j;
					continue;
				}
				$(tds[j]).hide();
			}
			j --;
			try {
				if(tds[i].innerHTML == tds[j].innerHTML) {
					$(tds[i]).attr('rowspan', j - i + 1);
				}
			} catch(ex) {
				
			}
		});								

	});

}




//같은  값이 있는 row 를 병합시킨다.
//n,n-1,n-2 column 을 병합시키다.

function TableColMerge2(id,colnum,showtableindex) {
	

	
	if (showtableindex == undefined)
		showtableindex = 0;
	

	$(id+' tbody:eq('+showtableindex +')').each(function() {

		var table = $(this).parent();
			
			$.each([colnum] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML ||tds1[i].innerHTML != tds1[j].innerHTML  ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML && tds1[i].innerHTML == tds1[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-1] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});				
			
	});

}



// 같은  값이 있는 row 를 병합시킨다.
// n,n-1,n-2 column 을 병합시키다. 
function TableColMerge3(id,colnum,showtableindex) {
	
	
	
	if (showtableindex == undefined)
		showtableindex = 0;

	
	$(id+' tbody:eq('+showtableindex +')').each(function() {
		var table = $(this).parent();
 

			$.each([ colnum] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide(); 
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-1] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML ||tds1[i].innerHTML != tds1[j].innerHTML  ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML && tds1[i].innerHTML == tds1[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-2] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});								
	
	});

}



//같은  값이 있는 row 를 병합시킨다.
//n,n-1,n-2,n-3 column 을 병합시키다. 
function TableColMerge4(id,colnum,showtableindex) {
	
	

	
	if (showtableindex == undefined)
		showtableindex = 0;
	
	
	$(id+' tbody:eq('+showtableindex +')').each(function() {
		var table = $(this).parent();

			$.each([ colnum] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					|| tds3[i].innerHTML == tds3[j].innerHTML		
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
	
			
			
			$.each([ colnum-1] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-2] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML ||tds1[i].innerHTML != tds1[j].innerHTML  ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML && tds1[i].innerHTML == tds1[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-3] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});									   
	   
	});

}


//같은  값이 있는 row 를 병합시킨다.
//n,n-1,n-2,n-3,n-4 column 을 병합시키다. 
function TableColMerge5(id,colnum,showtableindex) {
	


	if (showtableindex == undefined)
		showtableindex = 0;

	
	$(id+' tbody:eq('+showtableindex +')').each(function() {
		var table = $(this).parent();
		
			$.each([ colnum] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				var tds4 = $('>tbody>tr>td:nth-child(' + (v-4) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML || tds4[i].innerHTML != tds4[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					&& tds3[i].innerHTML == tds3[j].innerHTML && tds4[i].innerHTML == tds4[j].innerHTML				
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
	
			
			
			
			$.each([ colnum-1] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					&& tds3[i].innerHTML == tds3[j].innerHTML		
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
	
			
			
			$.each([ colnum-2] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-3] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML ||tds1[i].innerHTML != tds1[j].innerHTML  ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML && tds1[i].innerHTML == tds1[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-4] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});										
	});

}

//같은  값이 있는 row 를 병합시킨다.
//n,n-1,n-2,n-3,n-4,n-5 column 을 병합시키다. 
function TableColMerge6(id,colnum,showtableindex) {
	

	if (showtableindex == undefined)
		showtableindex = 0;
	
	$(id+' tbody:eq('+showtableindex +')').each(function() {
		var table = this;
	
	 		var table = $(this).parent();
			$.each([ colnum] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				var tds4 = $('>tbody>tr>td:nth-child(' + (v-4) + ')', table).toArray();
				var tds5 = $('>tbody>tr>td:nth-child(' + (v-5) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML || tds4[i].innerHTML != tds4[j].innerHTML || tds5[i].innerHTML != tds5[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					&& tds3[i].innerHTML == tds3[j].innerHTML && tds4[i].innerHTML == tds4[j].innerHTML && tds5[i].innerHTML == tds5[j].innerHTML				
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([ colnum-1] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				var tds4 = $('>tbody>tr>td:nth-child(' + (v-4) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML || tds4[i].innerHTML != tds4[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					&& tds3[i].innerHTML == tds3[j].innerHTML && tds4[i].innerHTML == tds4[j].innerHTML				
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
	
			
			
			
			$.each([ colnum-2] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				var tds3 = $('>tbody>tr>td:nth-child(' + (v-3) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ||
							tds3[i].innerHTML != tds3[j].innerHTML
					) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML
					&& tds3[i].innerHTML == tds3[j].innerHTML		
					) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
	
			
			
			$.each([ colnum-3] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				var tds2 = $('>tbody>tr>td:nth-child(' + (v-2) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML || tds1[i].innerHTML != tds1[j].innerHTML || tds2[i].innerHTML != tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML &&  tds1[i].innerHTML == tds1[j].innerHTML && tds2[i].innerHTML == tds2[j].innerHTML ) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-4] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				var tds1 = $('>tbody>tr>td:nth-child(' + (v-1) + ')', table).toArray();
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML ||tds1[i].innerHTML != tds1[j].innerHTML  ) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML && tds1[i].innerHTML == tds1[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});
			
			$.each([colnum-5] /* 합칠 칸 번호 */, function(c, v) {
				var tds = $('>tbody>tr>td:nth-child(' + v + ')', table).toArray(), i = 0, j = 0;
				for(j = 1; j < tds.length; j ++) {
					if(tds[i].innerHTML != tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i);
						i = j;
						continue;
					}
					$(tds[j]).hide();
				}
				j --;
				try {
					if(tds[i].innerHTML == tds[j].innerHTML) {
						$(tds[i]).attr('rowspan', j - i + 1);
					}
				} catch(ex) {
					
				}
			});								
		
	  	 
	});

}

// sleep 함수 
function sleep (interval, callback) {
	var timer = setInterval(function() {   
        clearInterval(timer);
        callback();
        return;
	}, interval); 
} //wait

 

// 평균 field 를 만든다.
function makeRatio(data,plan,result,ratio) {
	for(var i=0;i<data.length;i++) {
		
	  if (data[i][result]== 0 || data[i][result] == null || data[i][result] == undefined ) {
		  
		  data[i][ratio] = 0;  
		  continue;
	  }
	  
	  if (data[i][plan] >data[i][result]) {
		  data[i][ratio] =100;  
		  continue;
	  }
	  
	  data[i][ratio] = parseInt(data[i][plan]*100/data[i][result]);	
		
	}				
}


// 일치하는 문자열을 모두 치환한다.
function replaceAll(str, searchStr, replaceStr) {
    return str.split(searchStr).join(replaceStr);
}


//1월 부터 12월 까지 항목으로 바꾼다.
function convertrowtocoloumMonth(data) {
	var retdata=[];
	
	if (data.length <1)
		return retdata;
	for(var i=1;i<13;i++) {
		var tempdata ={};
		var rtype="";
		var ptype="";
		var ratio="";
  		
		if (i<10) {
		  	rtype="r0"+i;
		  	ptype="p0"+i;
		  	ratio="ratio0"+i;
		  	
		} else {
			rtype="r"+i;
		  	ptype="p"+i;
		  	ratio="ratio"+i;

		}
		
		tempdata.chkMonth = ""+i;
		
		tempdata.rtype = data[0][rtype];
		tempdata.ptype = data[0][ptype];
		tempdata.ratio = data[0][ratio];
		retdata.push(tempdata);				
	}
	
	
	return retdata;
}

//튼  숫자 값 가져 오기 
function getmaxfromdata(data,viewfield) {
	var max = 0;
	
	for(i=0;i<data.length;i++) {
		for(j=0;j<viewfield.length;j++) {
			var filed = viewfield[j];
			if (data[i][filed] == undefined || data[i][filed] == null)
				continue;
			if (data[i][filed]>max) 
				max = data[i][filed]; 
		}
          		
	} 
	return max;
}

// 작은 숫자 값 가져 오기 
function getminfromdata(data,viewfield) {
	var min = 0;
	
	for(i=0;i<data.length;i++) {
		for(j=0;j<viewfield.length;j++) {
			var filed = viewfield[j];
			if (data[i][filed] == undefined || data[i][filed] == null)
				continue;			
			if (data[i][filed]<min) 
				min = data[i][filed]; 
		}
          		
	} 
	return min;
}
 
// 엔터 key 값을  <br> 로 변경
function CarrigeToBr(data,field) {
	
	for(var i=0;i<data.length;i++) {
		try {
			data[i][field] =replaceAll(data[i][field],"\r\n","<br />");
			data[i][field] =replaceAll(data[i][field],"\n\r","<br />");
			data[i][field] =replaceAll(data[i][field],"\r","<br />");
			data[i][field] =replaceAll(data[i][field],"\n","<br />");
		
		} catch (ex) {
			
		}
		 
	}
	
}


// 가장 큰  데이타 가져 오기 
function getdatamax(data1,data2,fields) {
	 
	var max = getmaxfromdata(data1,fields);
	var compmax = getmaxfromdata(data2,fields);
	
	if (max <compmax) 
		max = compmax;
	return max; 
}



   
// 컴마 삭제 
function removeComma(data,collist) {
	for(var i in data) {
		for (var col in collist) {
			if (data[i][collist[col]] == undefined )
				continue;
				
			data[i][collist[col]] = data[i][collist[col]].replace(/,/g, '');
		}
    }		
}

// 슛자로 변경 
function toNumber(data,collist) {
	for(var i in data) {
		for (var col in collist) {
			if (data[i][collist[col]] == undefined )
				continue;
				
			data[i][collist[col]] = Number(data[i][collist[col]].replace(/,/g, ''));
		}
    }		
}





// time zone 을 기자고 현재 시간 가져오기
function GetTimeStr(timezone) {
	
	if (timezone == undefined) 
		return;
	var date =  new Date();
//    console.log(date.toJSON());
	var jun = moment(date.toJSON());
//	var dec = moment("2014-12-01T12:00:00Z");

    

//		var timestr = jun.tz('America/Los_Angeles').format();  // 5am PDT


    var timestr = jun.tz(timezone).format()
	var time = timestr.split("T")[1];
	
//	var time = date.toJSON().split("T")[1];
	
	var timearray = time.split(":");
	
	
	
	var timesec =   timearray[2].substring(0,2);
	
//	var showtime = timearray[0]+":"+timearray[1]+":"+timesec;
		var showtime = timearray[0]+":"+timearray[1]
	return showtime;
	
}



// IE version check 
// IE version 이 아니면  -1 
// IE version 이면 버전 번호 
function get_version_of_IE () { 

	 var word; 
	 var version = -1; 

	 var agent = navigator.userAgent.toLowerCase(); 
	 var name = navigator.appName; 

	 // IE old version ( IE 10 or Lower ) 
	 if ( name == "Microsoft Internet Explorer" ) word = "msie "; 

	 else { 
		 // IE 11 
		 if ( agent.search("trident") > -1 ) word = "trident/.*rv:"; 

		 // Microsoft Edge  
		 else if ( agent.search("edge/") > -1 ) word = "edge/"; 
	 } 

	 var reg = new RegExp( word + "([0-9]{1,})(\\.{0,}[0-9]{0,1})" ); 

	 if (  reg.exec( agent ) != null  ) version = RegExp.$1 + RegExp.$2; 
	 
	 version = parseInt (version);

	 return version; 
} 
