﻿function sideGnb(){
	var sideHtml = ''; 
		sideHtml += '<aside id="asideWrap">';
			sideHtml += '<h1><a href="intro.html">KIBI<small>@</small>RIA Plus</a></h1>';
			sideHtml += '<nav id="Gnb">'; 
				sideHtml += '<ul class="sideGnb">'; 
					sideHtml += '<li><p class="depth_1"><a class="gnb1">Editors</a></p>';
						sideHtml += '<ul class="depth_2">';
							sideHtml += '<li><a href="Editors_1.html" class="gnb1_1">DatePicker</a></li>';
							sideHtml += '<li><a href="Editors_2.html" class="gnb1_2">Editor Components</a></li>';
							sideHtml += '<li><a href="Editors_3.html" class="gnb1_3">Upload &amp; ListBox</a></li>';
						sideHtml += '</ul>';
					sideHtml += '</li>';

					sideHtml += '<li><p class="depth_1"><a class="gnb2">Grid</a></p>';
						sideHtml += '<ul class="depth_2">';
							sideHtml += '<li><a href="grid_1.html" class="gnb2_1">Grid / Basic</a></li>';
							sideHtml += '<li><a href="grid_2.html" class="gnb2_2">Functionality</a></li>';
							sideHtml += '<li><a href="grid_3.html" class="gnb2_3">Data Editors</a></li>';
							sideHtml += '<li><a href="grid_4.html" class="gnb2_4">Aggregates</a></li>';
						sideHtml += '</ul>';
					sideHtml += '</li>';

					sideHtml += '<li><p class="depth_1"><a class="gnb3">Charts</a></p>';
						sideHtml += '<ul class="depth_2">';
							sideHtml += '<li><a href="chart_1.html" class="gnb3_1">Column Chart</a></li>';
							sideHtml += '<li><a href="chart_2.html" class="gnb3_2">And more Chart</a></li>';
						sideHtml += '</ul>';
					sideHtml += '</li>';

					sideHtml += '<li><p class="depth_1"><a class="gnb4">Navigation</a></p>';
						sideHtml += '<ul class="depth_2">';
							sideHtml += '<li><a href="nav_1.html" class="gnb4_1">Tab &amp; TreeView</a></li>';
							sideHtml += '<li><a href="nav_2.html" class="gnb4_2">Tooltip &amp; Window</a></li>';
							sideHtml += '<li><a href="nav_3.html" class="gnb4_3">Button &amp; Icons</a></li>'; 
						sideHtml += '</ul>';
					sideHtml += '</li>';

					sideHtml += '<li><p class="depth_1"><a class="gnb6">Organization</a></p>';
						sideHtml += '<ul class="depth_2">';
							sideHtml += '<li><a href="org_1.html" class="gnb6_1">Organization / Basic</a></li>';
							sideHtml += '<li><a href="org_2.html" class="gnb6_2">Customizing</a></li>';
						sideHtml += '</ul>';
					sideHtml += '</li>';
				sideHtml += '</ul>';
			sideHtml += '</nav>'; 
		sideHtml += '</aside>';	

	document.write(sideHtml);
}
sideGnb();