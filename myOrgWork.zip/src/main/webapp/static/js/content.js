﻿/****************************
   브라우져별 전체 Height 값 구하기
****************************/
var userAgent = navigator.userAgent.toLowerCase();
 
var browser = {
	msie    : /msie/.test( userAgent ) && !/opera/.test( userAgent ),
	safari  : /webkit/.test( userAgent ),
	firefox : /mozilla/.test( userAgent ) && !/(compatible|webkit)/.test( userAgent ),
	opera   : /opera/.test( userAgent )
};   

window.onload = function (){  
	var totalHeight = 0; 

	if( browser.msie ){ //IE
		var scrollHeight = document.documentElement.scrollHeight;
		var browserHeight = document.documentElement.clientHeight;

		totalHeight = scrollHeight < browserHeight ? browserHeight : scrollHeight;

	} else if ( browser.safari ){ //Chrome || Safari
		totalHeight = document.body.scrollHeight;

	} else if ( browser.firefox ){ // Firefox || NS
		var bodyHeight = document.body.clientHeight;

		totalHeight = window.innerHeight < bodyHeight ? bodyHeight : window.innerHeight;

	} else if ( browser.opera ){ // Opera
		var bodyHeight = document.body.clientHeight;

		totalHeight = window.innerHeight < bodyHeight ? bodyHeight : window.innerHeight;

	} else { 
		alert("지원하지 않는 브라우져!!");
	}

	winResize(); 
	
	var bodyName = $('body').attr('class');   //   window popup시 체크
	if(bodyName=='WrapperPOP') $('html').addClass('overflowAuto');
	else $('html').removeClass('overflowAuto');
}

function winResize() {     
	var screenHeight = $(window).innerHeight(),
		titHeight = $('.h2_tit').innerHeight(),  
		footerHeight = $('.footerWrap').innerHeight();   

	$('#asideWrap').css('height', screenHeight); 
	$('#containerWrap').css('height', screenHeight-footerHeight); 
	$('#Gnb , #Gnb .jspContainer').css('height', screenHeight-titHeight); 
	$('#Gnb').jScrollPane(); 
};


$(window).resize(function() {
	winResize();
}); 


/****************************
   popup
****************************/ 
//   window 팝업
function openWin_POP(url,pop,width,height,scroll,resize){
	var winpopB = window.open(url,pop,'top='+((screen.availHeight - height)/2 - 40) +', left='+(screen.availWidth - width)/2+', width='+width+', height='+height+', toolbar=0, directories=0, status=0, menubar=0, scrollbars='+scroll+', resizable='+resize+'');
	if(winpopB){
		winpopB.focus();
	}
}  


/****************************
   GNB 인식
****************************/
$('document').ready(function(){  	
	if(typeof afterJQueryInit == 'function') { 
	   afterJQueryInit();
	};
});

function gnb_depth(Gn, Sn) {
	$('.'+Gn).parents('li').addClass('current');     //  1depth 메뉴인식
	$('.'+Sn).parent().addClass('current');     //  2depth 메뉴인식 
}; 



/****************************
   Contents
****************************/
$(function() { 
	//  같은 열 데이터 병합
	$.fn.rowspanTable = function(colIdx, isStats) {       
		return this.each(function(){      
			var that;     
			$('tr', this).each(function(row) {      
				$('td:eq('+colIdx+')', this).filter(':visible').each(function(col) {
					if ($(this).html() == $(that).html() && (!isStats || isStats && $(this).prev().html() == $(that).prev().html()) ) {            
						rowspan = $(that).attr("rowspan") || 1;
						rowspan = Number(rowspan)+1;
						$(that).attr("rowspan",rowspan);
						$(this).hide();
					} else {            
						that = this;         
					}          
					that = (that == null) ? this : that;      
				});     
			});    
		});  
	}; 


	//      Side Gnb Toggle
	$('#Gnb .depth_1').on('click',function(){     
		$(this).parent('li').toggleClass('shut'); 
		$(this).next('.depth_2').slideToggle(200); 
	});  


	//    소스 코드 View   
	var popSource =$("#popSource").kendoWindow({ 
		maxWidth: "80%",
		minWidth: 500, 
		minHeight: 200,
		modal: true, 
		visible: false, 
		animation: false, 
		resizable: false, 
		close: function() {
			$('.popModal_wrap').empty();
		}
    }).data("kendoWindow");

	$('.codeView_popup').on('click',function(){     //     modal
		var mHeight = $(window).innerHeight()-150,
			sHtml = $(this).siblings('.sourceHtml').html(),  
			sTitle = $('.h3_tit').eq($("[class^='codeView_']").index($(this))).text();  

		$('.popModal_wrap').append('<prev>'+sHtml+'</prev>');
		popSource.setOptions({ 
			maxHeight: mHeight,
			title: sTitle
		});
		popSource.center().open().wrapper.addClass('codeViewModal');  
	});  

	$('.codeView_open').on('click',function(){      //    inline
		if($(this).hasClass('on')){
			$(this).removeClass('on');
			$(this).text('Show Code');
			$(this).siblings('.sourceHtml').slideUp(200);
		} else {
			$(this).addClass('on');
			$(this).text('Close Code');
			$(this).siblings('.sourceHtml').slideDown(200);
		}
	}); 

	$('#showCodeAll').on('click',function(){    //   소스 코드 전체 토글
		if($(this).is(':checked')){
			$('.codeView_open').addClass('on');
			$('.codeView_open').text('Close Code');
			$('.codeView_open').siblings('.sourceHtml').slideDown(200);
		} else {
			$('.codeView_open').removeClass('on');
			$('.codeView_open').text('Show Code');
			$('.codeView_open').siblings('.sourceHtml').slideUp(200);
		}
	}); 

	
	//    label width Auto
	$('.RiaCommon').each(function(){
		var labelArray = [];
		$(this).find('.label_tit').each(function(){  
			var labelW = $(this).width();
			labelArray.push(labelW);
		});  
		var maxLabel = Math.max.apply(Math, labelArray);
		$(this).find('.label_tit').css('width', maxLabel+25);
	});


	//    mouse guide popup 알림창 -  3초후 사라짐 
	setTimeout(function() {
		$('.mouseGuide').fadeOut(400);  
	}, 2000); 


});




